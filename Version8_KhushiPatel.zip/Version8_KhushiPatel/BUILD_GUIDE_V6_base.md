# The Recipe Box – Version 6 base build guide (unchanged in V7; V7 additions are in BUILD_GUIDE_V7.md)

This guide rebuilds Version 5 in **Microsoft Power Apps** (LCNC) on **Dataverse**,
then adds the AI-powered publishing workflow in **Power Automate** with **AI Builder**.
Follow it in order; every formula below is written for the table and column names
given in Part B, so keep those names exactly.

> **Names to check in your own environment.** Dataverse gives every column a
> *logical* name with your publisher prefix (for example `cr8a1_status`). Power Fx
> uses the **display names** shown here, but OData filters in flows use the
> **logical names**. Wherever you see `cr_` below, replace it with your prefix
> (Tables → Recipe → Columns → open the column → *Advanced options* → Logical name).

---

## Part A – Set up the platform (Lab Step 1)

1. Sign up for the free **Power Apps Developer Plan** with your **university
   (work/school) Microsoft account** – personal Outlook/Gmail accounts are not accepted.
2. In <https://make.powerapps.com> confirm the environment picker (top right) shows
   *"Khushi Patel's Environment"* (a developer environment with Dataverse).
3. **Solutions → New solution** → Display name `Recipe Box V6`, publisher: create
   `KhushiPatel` (prefix e.g. `kp`). Build **everything** (tables, app, flows,
   prompt, environment variables) *inside this solution* so it can be exported for
   submission.
4. Add two **environment variables** to the solution (Text):
   `RB Default Reviewer Email`, `RB App URL` (fill the URL after Part C, step 1).
5. For multi-participant testing you need **at least two, ideally three** accounts
   (you as Cook, a Reviewer, an Editor). Ask two classmates in your university
   tenant, share the app with them, and give them the *Basic User* role plus the
   `RB Reviewer` role from step B5. If you can only use one account, say so in your
   documentation and test each role by editing your own row in **App Users**.

---

## Part B – Database (Dataverse)

### B1. Tables and columns

Create each table in the solution (**New → Table → Table**). Text = single line of
text (max length shown), Multi = multiple lines of text.

**Recipe** (plural *Recipes*) – rename the primary column to **Title** (Text 120)

| Column | Type | Notes |
|---|---|---|
| Recipe Code | Text 60 | V5 `id`; add a **key** on it (Keys → New key) |
| Category | Text 20 | `breakfast` / `dinner` / `dessert` (same strings as V5 and the API) |
| Blurb | Text 300 | |
| Image Url | Text 500 | V5 image path or a `https://` URL |
| Image Alt | Text 200 | accessibility, as in V5 |
| Time Minutes | Whole number | 1–1440, blank for imports |
| Time Label | Text 40 | |
| Is Quick | **Formula (Yes/No)** | `If(IsBlank('Time Minutes'), false, 'Time Minutes' <= 15)` – V5's `QUICK_MINUTES` rule now lives in the database |
| Is Veg | Yes/No | |
| Keywords | Text 300 | |
| Search Text | Multi 4000 | lowercase title + keywords + ingredient text (V5 search haystack) |
| Base Servings | Whole number | 1–50 |
| Serving Options | Text 40 | e.g. `1,2,4` |
| Serving Unit Label | Text 30 | |
| Source | Text 20 | `built-in` / `custom` / `imported` |
| Source Url | Text 500 | attribution for TheMealDB imports |
| Status | Text 30 | see status model in Part D |
| Submitted By | Text 200 (email) | |
| Submitted On | Date and time | |
| Stage Started On | Date and time | set by the flow at each status change (drives reminders) |
| Assigned Reviewer | Text 200 (email) | |
| Published On | Date and time | |
| Reviewer Comments | Multi 2000 | |
| AI Category | Text 20 | |
| AI Tags | Text 300 | comma-separated |
| AI Allergens | Text 300 | comma-separated |
| AI Veg Conflict | Text 300 | |
| AI Issues | Multi 2000 | one per line |
| AI Summary | Multi 1000 | |
| AI Confidence | Decimal (2 places) | 0–1 |
| AI Needs Attention | Yes/No | |

**Ingredient** – primary column *Name*; columns: **Line No** (Whole number),
**Amount** (Decimal, 3 places, optional – blank = "to taste" like V5's `null`),
**Unit** (Text 30), **Text** (Text 300).

**Step** – primary *Name*; **Step No** (Whole number), **Text** (Multi 2000).

**Favorite** – primary *Name*; **User Email** (Text 200).

**Shopping Entry** – primary *Name*; **Servings** (Whole number), **User Email**.

**Shopping Extra** – rename primary to **Text**; **User Email**.

**Shopping Checked** – rename primary to **Item Key**; **User Email**.

**Workflow Audit** – primary *Name*; **Recipe Title** (Text 120), **Action** (Text 100),
**Actor** (Text 200), **Actor Type** (Text 10: `Human` / `AI` / `System`),
**From Status**, **To Status** (Text 30), **Notes** (Multi 4000), **Logged On** (Date and time).

**Reviewer Assignment** – rename primary to **Category**; **Reviewer Email**, **Editor Email**.

**App User** – rename primary to **Email**; **Display Name** (Text 100), **Role** (Text 20:
`Cook` / `Reviewer` / `Editor`).

### B2. Relationships (replaces V5's cascade-delete transaction)

On **Ingredient, Step, Favorite, Shopping Entry**: add a **Lookup** column named
**Recipe** → table *Recipe*. Then open *Recipe → Relationships*, edit each of those
four relationships → **Type of behavior: Parental** (delete a recipe and Dataverse
deletes its ingredients, steps, favourites and shopping rows – exactly what V5's
`database.js` did in one IndexedDB transaction).

On **Workflow Audit**: lookup **Recipe** with behaviour **Referential, Remove Link**
(the audit trail survives if a recipe is deleted – a governance requirement).

### B3. Import the Version 5 data

Use **Tables → Recipe → Import → Import data from Excel/CSV** with
`lcnc-data/Recipes.csv` (map columns by name), then `Ingredients.csv` and
`Steps.csv` (map the **Recipe** column to the lookup; it matches on **Title**),
then `ReviewerAssignments.csv` and `AppUsers.csv` – **replace the example emails
with real ones first**. Result: 6 built-in recipes, 31 ingredients, 23 steps.

Upload the 9 SVGs from V5's `images/` folder later as app **Media** (Part C).

### B4. Validation in the database

Recipe → **Business rules** (or column min/max): Time Minutes 1–1440, Base Servings
1–50. These protect the data even if someone edits it outside the app (V5's
`server/validate.js` played this role).

### B5. Security

Create security role **RB Reviewer** (copy *Basic User*, give Organization-level
Read on Recipe/Ingredient/Step/Workflow Audit). Cooks keep *Basic User* (User-level
write = they can only change rows they own). This is real row-level security,
which V5's single shared API key could not provide.

---

## Part C – The canvas app (UI + logic)

**Create → Blank canvas app → Tablet** (or *Phone*), name `Recipe Box V6`, inside the
solution. Add data: all tables from Part B. Add the flows from Part E later
(Power Automate pane → *Add flow*).

### C1. App settings and named formulas

**App.Formulas**

```powerfx
gblMe = LookUp('App Users', Email = User().Email);
gblRole = Coalesce(gblMe.Role, "Cook");
gblIsReviewer = gblRole = "Reviewer" || gblRole = "Editor";

// V5 quantityFormat.formatQuantity, rewritten as a user-defined function
FormatQty(a: Number): Text =
    With({w: RoundDown(a + 0.000000001, 0)},
        With({r: a - w, p: If(w > 0, Text(w) & " ", "")},
            If(r < 0.02, Text(w),
               r > 0.98, Text(w + 1),
               Abs(r - 0.25) <= 0.04, p & "1/4",
               Abs(r - 1/3)  <= 0.04, p & "1/3",
               Abs(r - 0.5)  <= 0.04, p & "1/2",
               Abs(r - 2/3)  <= 0.04, p & "2/3",
               Abs(r - 0.75) <= 0.04, p & "3/4",
               Text(Round(a, 1)))));

// V5 recipeBuilderService.parseNumber: "1 1/2" -> 1.5, "1/4" -> 0.25, "2" -> 2
ParseAmount(s: Text): Number =
    If("/" in s,
       If(" " in s,
          Value(First(Split(s, " ")).Value) +
            Value(First(Split(Last(Split(s, " ")).Value, "/")).Value) /
            Value(Last(Split(Last(Split(s, " ")).Value, "/")).Value),
          Value(First(Split(s, "/")).Value) / Value(Last(Split(s, "/")).Value)),
       Value(s));
```

If the editor rejects `FormatQty(...)`/`ParseAmount(...)`, turn on **Settings →
Updates → User-defined functions**. (If your version has no such switch, paste the
function body inline where it is used, replacing `a`/`s` with the value.)

**App.OnStart**

```powerfx
Set(varDark, false);
Set(varFilters, Table({F: "none"}));   // creates the table shape
Clear(varFilters);
If(!IsBlank(Param("recipeId")),
   Set(varRecipe, LookUp(Recipes, 'Recipe Code' = Param("recipeId"))));
```

**App.StartScreen**: `If(IsBlank(varRecipe), scrBrowse, scrDetail)` – this lets the
approval email deep-link straight to a recipe.

Upload the V5 SVGs: **Media → Upload** (`eggs-skillet.svg` …). Recipe image property
used everywhere:

```powerfx
Switch(ThisItem.'Image Url',
  "images/eggs-skillet.svg", 'eggs-skillet',
  "images/oats-jar.svg", 'oats-jar',
  "images/pasta-bowl.svg", 'pasta-bowl',
  "images/lentil-stew.svg", 'lentil-stew',
  "images/mug-cake.svg", 'mug-cake',
  "images/berries-yogurt.svg", 'berries-yogurt',
  "images/placeholder-breakfast.svg", 'placeholder-breakfast',
  "images/placeholder-dinner.svg", 'placeholder-dinner',
  "images/placeholder-dessert.svg", 'placeholder-dessert',
  ThisItem.'Image Url')        // https:// URLs from TheMealDB
```

**Theme (V5 themeService)**: a toggle `tglDark` in the header, `OnChange: Set(varDark, Self.Value)`.
Screen Fill: `If(varDark, RGBA(28,25,23,1), RGBA(255,251,245,1))`; label Color:
`If(varDark, RGBA(245,245,244,1), RGBA(41,37,36,1))`.

### C2. Screens

| Screen | Replaces in V5 | Main controls |
|---|---|---|
| `scrBrowse` | index.html grid + filter pills + search | header, `txtSearch`, 7 filter toggles, `galRecipes`, footer status |
| `scrDetail` | expanded recipe card | image, `ddServings`, `galIngredients`, `galSteps`, ♥ favourite, *Add to list*, *Edit*, *Delete*, *Submit for publishing* |
| `scrAddEdit` | addRecipeController form | text inputs + error labels |
| `scrShopping` | shoppingListController | `galShopping`, add-extra input, *Copy*, *Untick all* |
| `scrDiscover` | discoverController dialog | `txtQ`, `galDiscover`, *Import* |
| `scrMySubmissions` | **new in V6** | `galMine`, status pill, `galTimeline` |
| `scrReviewQueue` | **new in V6** (Reviewer/Editor only) | `galQueue`, AI panel, *Open approval* |

Navigation bar (a horizontal gallery or buttons) on every screen. The *Review queue*
button: `Visible = gblIsReviewer`.

### C3. Browse – search and filters (V5 searchFilterService)

Seven **Toggle** (or Checkbox) controls: `chkQuick`, `chkVeg`, `chkFavs`, `chkMine`
(attribute filters, combined with AND) and `chkBreakfast`, `chkDinner`, `chkDessert`
(category filters, combined with OR) – the same rules as V5.

`scrBrowse.OnVisible`

```powerfx
ClearCollect(colFavIds,
    ForAll(Filter(Favorites, 'User Email' = User().Email) As f, {Id: f.Recipe.Recipe}))
```

`galRecipes.Items`

```powerfx
With({anyCat: chkBreakfast.Value || chkDinner.Value || chkDessert.Value,
      q: Lower(Trim(txtSearch.Text))},
  Filter(Recipes,
    // what a user may see: built-in, published community recipes, and my own
    (Source = "built-in" || Status = "published" || 'Submitted By' = User().Email) &&
    (!chkQuick.Value || 'Is Quick') &&
    (!chkVeg.Value   || 'Is Veg') &&
    (!chkMine.Value  || Source <> "built-in") &&
    (!chkFavs.Value  || ThisRecord.Recipe in colFavIds.Id) &&
    (!anyCat ||
        (chkBreakfast.Value && Category = "breakfast") ||
        (chkDinner.Value    && Category = "dinner") ||
        (chkDessert.Value   && Category = "dessert")) &&
    (IsBlank(q) || q in 'Search Text')))
```

`galRecipes` card: image (C1), `ThisItem.Title`, `ThisItem.'Time Label'`, a badge
`If(ThisItem.'Is Veg', "🌱 Veg", "")`, a source badge
`Switch(ThisItem.Source, "custom", "My recipe", "imported", "From TheMealDB", "")`,
and a status badge for non-built-in rows: `If(ThisItem.Source <> "built-in", ThisItem.Status)`.
`OnSelect: Set(varRecipe, ThisItem); Navigate(scrDetail, ScreenTransition.Cover)`.

Footer (V5 "Live database" status):

```powerfx
"Dataverse · " & CountRows(Filter(Recipes, Source = "built-in")) & " built-in + " &
CountRows(Filter(Recipes, 'Submitted By' = User().Email && Source <> "built-in")) &
" of your own recipes · " & CountRows(colFavIds) & " favourites · signed in as " & gblRole
```

> *Delegation:* `in` (substring) and `CountRows` are not delegable to Dataverse.
> With hundreds of recipes this is fine (the app setting *Data row limit* defaults
> to 500, raise it to 2000). Record the yellow warning triangles in your
> troubleshooting log and explain why you accepted them.

### C4. Detail – scaling, favourite, shopping list (V5 scalingService, favoritesService)

`ddServings` (classic Drop down): `Items = Split(varRecipe.'Serving Options', ",")`,
`Default = Text(varRecipe.'Base Servings')`.

`galIngredients.Items = Sort(Filter(Ingredients, Recipe.Recipe = varRecipe.Recipe), 'Line No')`

Ingredient label `Text`:

```powerfx
If(IsBlank(ThisItem.Amount), ThisItem.Text,
   FormatQty(ThisItem.Amount * Value(ddServings.Selected.Value) / varRecipe.'Base Servings')
   & " " & ThisItem.Text)
```

`galSteps.Items = Sort(Filter(Steps, Recipe.Recipe = varRecipe.Recipe), 'Step No')`,
label: `ThisItem.'Step No' & ". " & ThisItem.Text`.

Favourite label (text "♥" / "♡"), `OnSelect`:

```powerfx
With({f: LookUp(Favorites, Recipe.Recipe = varRecipe.Recipe && 'User Email' = User().Email)},
  If(IsBlank(f),
     Patch(Favorites, Defaults(Favorites),
           {Name: varRecipe.Title, Recipe: varRecipe, 'User Email': User().Email}),
     Remove(Favorites, f)))
```

`Text: If(IsBlank(LookUp(Favorites, Recipe.Recipe = varRecipe.Recipe && 'User Email' = User().Email)), "♡", "♥")`

*Add to shopping list* `OnSelect` (V5 `addRecipe`: adding again updates the servings):

```powerfx
With({e: LookUp('Shopping Entries', Recipe.Recipe = varRecipe.Recipe && 'User Email' = User().Email),
      n: Value(ddServings.Selected.Value)},
  If(IsBlank(e),
     Patch('Shopping Entries', Defaults('Shopping Entries'),
           {Name: varRecipe.Title, Recipe: varRecipe, Servings: n, 'User Email': User().Email}),
     Patch('Shopping Entries', e, {Servings: n})));
Notify(varRecipe.Title & " added to your shopping list", NotificationType.Success)
```

Own-recipe buttons (V5: built-in recipes are read-only):

```powerfx
// btnEdit.Visible / btnDelete.Visible
varRecipe.Source <> "built-in" && varRecipe.'Submitted By' = User().Email &&
!(varRecipe.Status in ["submitted", "ai_checked", "in_review", "editor_review"])
```

`btnEdit.OnSelect: Set(varEdit, varRecipe); Navigate(scrAddEdit)`

`btnDelete.OnSelect: UpdateContext({ctxConfirm: true})` → a confirm container with
*Yes*: `Remove(Recipes, varRecipe); Set(varRecipe, Blank()); Navigate(scrBrowse)`
(the Parental relationships delete the child rows).

*Submit for publishing* (`Visible` when own recipe and Status is `draft`,
`changes_requested` or `rejected`):

```powerfx
Patch(Recipes, varRecipe, {Status: "submitted", 'Submitted On': Now(), 'Stage Started On': Now()});
Set(varRecipe, LookUp(Recipes, Recipe = varRecipe.Recipe));
Notify("Sent for review. Track it under My submissions.", NotificationType.Success)
```

Allergen notice on detail (transparency): `Visible = !IsBlank(varRecipe.'AI Allergens')`,
`Text = "Contains (AI-suggested, checked by a reviewer): " & varRecipe.'AI Allergens' &
". Always check labels yourself."`

### C5. Add / Edit recipe (V5 recipeBuilderService)

Controls: `txtTitle`, `ddCategory` (`Items = ["breakfast","dinner","dessert"]`),
`txtMinutes`, `txtServings`, `tglVeg`, `txtBlurb`, `txtIngredients` and `txtSteps`
(Mode = Multiline, one per line). `scrAddEdit.OnVisible` pre-fills when editing
(V5 `recipeToInput`):

```powerfx
If(!IsBlank(varEdit),
   UpdateContext({ctxIng: Concat(Sort(Filter(Ingredients, Recipe.Recipe = varEdit.Recipe), 'Line No'),
                    If(IsBlank(Amount), "", FormatQty(Amount) & " ") & Text, Char(10)),
                  ctxSteps: Concat(Sort(Filter(Steps, Recipe.Recipe = varEdit.Recipe), 'Step No'), Text, Char(10))}),
   UpdateContext({ctxIng: "", ctxSteps: ""}))
```

Set each input's `Default` to `varEdit.<column>` (e.g. `txtTitle.Default = varEdit.Title`,
`txtIngredients.Default = ctxIng`). Clear `varEdit` with `Set(varEdit, Blank())` on the
*＋ Add recipe* button.

`btnSave.OnSelect`

```powerfx
// ---- 1. lines (strip "- ", "* ", "• ", "1. " like V5 splitLines) ----
ClearCollect(colIng, Filter(ForAll(Split(Substitute(txtIngredients.Text, Char(13), ""), Char(10)) As l,
    With({t: Trim(l.Value), m: Match(Trim(l.Value), "^(?:[-*•]|\d+[.)])\s+(?<rest>.+)$")},
         {L: If(IsBlank(m), t, m.rest)})), !IsBlank(L)));
ClearCollect(colSteps, Filter(ForAll(Split(Substitute(txtSteps.Text, Char(13), ""), Char(10)) As l,
    With({t: Trim(l.Value), m: Match(Trim(l.Value), "^(?:[-*•]|\d+[.)])\s+(?<rest>.+)$")},
         {L: If(IsBlank(m), t, m.rest)})), !IsBlank(L)));

// ---- 2. validation (same rules and messages as V5 validate()) ----
Clear(colErrors);
If(IsBlank(Trim(txtTitle.Text)), Collect(colErrors, {Field: "title", Msg: "Give your recipe a name."}));
If(IsBlank(ddCategory.Selected.Value), Collect(colErrors, {Field: "category", Msg: "Pick a category."}));
If(!IsMatch(txtMinutes.Text, "\d+") || Value(txtMinutes.Text) < 1 || Value(txtMinutes.Text) > 1440,
   Collect(colErrors, {Field: "minutes", Msg: "Enter the time in whole minutes (1 or more)."}));
If(!IsMatch(txtServings.Text, "\d+") || Value(txtServings.Text) < 1 || Value(txtServings.Text) > 50,
   Collect(colErrors, {Field: "servings", Msg: "Enter how many it serves (1-50)."}));
If(CountRows(colIng) = 0, Collect(colErrors, {Field: "ingredients", Msg: "Add at least one ingredient (one per line)."}));
If(CountRows(colSteps) = 0, Collect(colErrors, {Field: "steps", Msg: "Add at least one step (one per line)."}));

// ---- 3. save ----
If(CountRows(colErrors) = 0,
  With({mins: Value(txtMinutes.Text), base: Value(txtServings.Text),
        title: Trim(txtTitle.Text), isNew: IsBlank(varEdit)},
    Set(varSaved, Patch(Recipes, If(isNew, Defaults(Recipes), varEdit), {
        Title: title,
        Category: ddCategory.Selected.Value,
        Blurb: Coalesce(Trim(txtBlurb.Text), "One of my own recipes."),
        'Time Minutes': mins,
        'Time Label': mins & If(mins = 1, " min", " mins"),
        'Is Veg': tglVeg.Value,
        'Base Servings': base,
        'Serving Options': Concat(Sort(Filter(Distinct([1, 2, 4, 6, 8, base], Value),
                                              Value <= Max(base * 2, 4)), Value), Value, ","),
        'Serving Unit Label': "serving",
        Keywords: Lower(title & " " & ddCategory.Selected.Value & If(tglVeg.Value, " vegetarian", "") & " mine custom"),
        'Image Url': If(isNew, "images/placeholder-" & ddCategory.Selected.Value & ".svg", varEdit.'Image Url'),
        'Image Alt': If(isNew, "Placeholder illustration for " & title, varEdit.'Image Alt'),
        Source: If(isNew, "custom", varEdit.Source),
        // editing a published recipe takes it back to draft: it must be reviewed again
        Status: If(isNew || varEdit.Status = "published", "draft", varEdit.Status),
        'Submitted By': User().Email,
        'Recipe Code': If(isNew, "c" & Text(Now(), "yyyymmddhhmmss"), varEdit.'Recipe Code')
    })));
  RemoveIf(Ingredients, Recipe.Recipe = varSaved.Recipe);
  RemoveIf(Steps, Recipe.Recipe = varSaved.Recipe);
  ForAll(Sequence(CountRows(colIng)) As n,
    With({L: Index(colIng, n.Value).L},
      With({m: Match(L, "^(?<amt>\d+ \d+/\d+|\d+/\d+|\d+(?:\.\d+)?) (?<rest>.+)$")},
        Patch(Ingredients, Defaults(Ingredients), {
          Name: varSaved.'Recipe Code' & "-I" & Text(n.Value, "00"),
          Recipe: varSaved, 'Line No': n.Value,
          Amount: If(IsBlank(m), Blank(), ParseAmount(m.amt)),
          Text: If(IsBlank(m), L, m.rest)}))));
  ForAll(Sequence(CountRows(colSteps)) As n,
    Patch(Steps, Defaults(Steps), {
      Name: varSaved.'Recipe Code' & "-S" & Text(n.Value, "00"),
      Recipe: varSaved, 'Step No': n.Value, Text: Index(colSteps, n.Value).L}));
  Patch(Recipes, varSaved, {'Search Text':
      Lower(varSaved.Title & " " & varSaved.Keywords & " " & Concat(colIng, L, " "))});
  Set(varRecipe, LookUp(Recipes, Recipe = varSaved.Recipe));
  Set(varEdit, Blank());
  Notify("Saved", NotificationType.Success);
  Navigate(scrDetail))
```

Error labels under each input: `Text = LookUp(colErrors, Field = "title").Msg`,
`Visible = !IsBlank(Self.Text)`, Color red.

### C6. Shopping list (V5 shoppingListService.buildItems)

`btnRefresh.OnSelect` (also call it from `scrShopping.OnVisible` with `Select(btnRefresh)`;
the button can be hidden):

```powerfx
ClearCollect(colChecked, Filter('Shopping Checked', 'User Email' = User().Email));
ClearCollect(colEntries, Filter('Shopping Entries', 'User Email' = User().Email));
ClearCollect(colShopRaw,
  Ungroup(
    ForAll(colEntries As e,
      {Lines: ForAll(Filter(Ingredients, Recipe.Recipe = e.Recipe.Recipe) As i,
         {Key: Lower(Trim(i.Text)), ItemText: i.Text,
          Amt: If(IsBlank(i.Amount), Blank(), i.Amount * e.Servings / e.Recipe.'Base Servings'),
          Src: e.Recipe.Title})}),
    Lines));
Collect(colShopRaw,
  ForAll(Filter('Shopping Extras', 'User Email' = User().Email) As x,
    {Key: Lower(Trim(x.Text)), ItemText: x.Text, Amt: Blank(), Src: "added by me"}));
ClearCollect(colShopping,
  SortByColumns(
    AddColumns(GroupBy(colShopRaw, Key, Rows),
      ItemText, First(Rows).ItemText,
      HasAmt, CountRows(Filter(Rows, !IsBlank(Amt))) > 0,
      Total, Sum(Filter(Rows, !IsBlank(Amt)), Amt),
      Sources, Concat(Distinct(Rows, Src), Value, ", "),
      IsChecked, Key in colChecked.'Item Key'),
    "IsChecked", SortOrder.Ascending, "ItemText", SortOrder.Ascending))
```

`galShopping.Items = colShopping`; label
`If(ThisItem.HasAmt, FormatQty(ThisItem.Total) & " ", "") & ThisItem.ItemText`,
small label `ThisItem.Sources`. Checkbox `Default = ThisItem.IsChecked`,

```powerfx
// OnCheck
Patch('Shopping Checked', Defaults('Shopping Checked'), {'Item Key': ThisItem.Key, 'User Email': User().Email}); Select(btnRefresh)
// OnUncheck
RemoveIf('Shopping Checked', 'Item Key' = ThisItem.Key && 'User Email' = User().Email); Select(btnRefresh)
```

Add item: `Patch('Shopping Extras', Defaults('Shopping Extras'), {Text: Trim(txtExtra.Text), 'User Email': User().Email}); Reset(txtExtra); Select(btnRefresh)` (`DisplayMode` disabled when `IsBlank(Trim(txtExtra.Text))`).

*Untick all*: `RemoveIf('Shopping Checked', 'User Email' = User().Email); Select(btnRefresh)`

*Copy* (V5 `toPlainText`):

```powerfx
Copy(Concat(Filter(colShopping, !IsChecked),
            If(HasAmt, FormatQty(Total) & " ", "") & ItemText, Char(10)));
Notify("Shopping list copied", NotificationType.Success)
```

A second gallery lists `colEntries` with a remove button:
`Remove('Shopping Entries', ThisItem); Select(btnRefresh)`.

### C7. Discover (TheMealDB) – uses Flow 3

`btnSearch.OnSelect`

```powerfx
With({q: Trim(txtQ.Text)},
  If(Len(q) < 2 || Len(q) > 60,
     Notify("Type 2 to 60 characters", NotificationType.Warning),
     UpdateContext({ctxBusy: true});
     IfError(
       ClearCollect(colDiscover,
         ForAll(Table(ParseJSON(RBDiscoverSearch.Run(q).results)) As r,
           {MealId: Text(r.Value.id), Title: Text(r.Value.title), Thumb: Text(r.Value.thumb),
            MealCategory: Text(r.Value.category), Area: Text(r.Value.area),
            Instructions: Text(r.Value.instructions), SourceUrl: Text(r.Value.source),
            IngredientsJson: JSON(r.Value.ingredients)})),
       Notify("TheMealDB is not answering right now. Try again later.", NotificationType.Error));
     UpdateContext({ctxBusy: false})))
```

`galDiscover.Items = colDiscover`, empty-state label `Visible = CountRows(colDiscover) = 0`.

*Import* `OnSelect` (V5 `mapMeal`: category mapping, base servings 2, veg from category, attribution):

```powerfx
With({mc: Lower(ThisItem.MealCategory),
      ing: ForAll(Table(ParseJSON(ThisItem.IngredientsJson)) As x, {L: Trim(Text(x.Value))}),
      st: Filter(ForAll(Split(Substitute(ThisItem.Instructions, Char(13), ""), Char(10)) As s,
                 {L: Trim(s.Value)}), Len(L) > 1)},
  Set(varSaved, Patch(Recipes, Defaults(Recipes), {
     Title: Left(ThisItem.Title, 80),
     Category: If("dessert" in mc, "dessert", "breakfast" in mc, "breakfast", "dinner"),
     Blurb: Left(ThisItem.Area & " " & ThisItem.MealCategory & " recipe from TheMealDB", 140),
     'Image Url': ThisItem.Thumb, 'Image Alt': "Photo of " & ThisItem.Title,
     'Time Label': "Time varies", 'Is Veg': "vegetarian" in mc || "vegan" in mc,
     'Base Servings': 2, 'Serving Options': "1,2,4", 'Serving Unit Label': "serving",
     Keywords: Lower(ThisItem.Title & " " & ThisItem.Area & " " & ThisItem.MealCategory),
     Source: "imported", Status: "draft", 'Submitted By': User().Email,
     'Recipe Code': "mealdb-" & ThisItem.MealId,
     'Source Url': Coalesce(ThisItem.SourceUrl, "https://www.themealdb.com")}));
  ForAll(Sequence(CountRows(ing)) As n,
    With({L: Index(ing, n.Value).L},
      With({m: Match(L, "^(?<amt>\d+ \d+/\d+|\d+/\d+|\d+(?:\.\d+)?) ?(?<rest>.*)$")},
        Patch(Ingredients, Defaults(Ingredients), {Name: varSaved.'Recipe Code' & "-I" & Text(n.Value, "00"),
          Recipe: varSaved, 'Line No': n.Value,
          Amount: If(IsBlank(m), Blank(), ParseAmount(m.amt)),
          Text: If(IsBlank(m), L, m.rest)}))));
  ForAll(Sequence(CountRows(st)) As n,
    Patch(Steps, Defaults(Steps), {Name: varSaved.'Recipe Code' & "-S" & Text(n.Value, "00"),
      Recipe: varSaved, 'Step No': n.Value, Text: Left(Index(st, n.Value).L, 600)}));
  Patch(Recipes, varSaved, {'Search Text': Lower(varSaved.Keywords & " " & Concat(ing, L, " "))}));
Notify("Imported as your own draft recipe", NotificationType.Success)
```

(Disable *Import* when a recipe with `'Recipe Code' = "mealdb-" & ThisItem.MealId` already
exists for you – V5 returned 409 `recipe_exists` in that case.)

### C8. My submissions – status tracking (new in V6)

`galMine.Items`

```powerfx
Sort(Filter(Recipes, 'Submitted By' = User().Email && Source <> "built-in"), 'Modified On', SortOrder.Descending)
```

Status pill: `Text = Switch(ThisItem.Status, "draft","Draft", "submitted","Submitted",
"ai_checked","AI checked", "in_review","With reviewer", "changes_requested","Changes requested",
"editor_review","With editor", "published","Published", "rejected","Rejected", ThisItem.Status)`,
`Fill = Switch(ThisItem.Status, "published", RGBA(22,163,74,1), "rejected", RGBA(220,38,38,1),
"changes_requested", RGBA(217,119,6,1), RGBA(100,116,139,1))`.

Progress stepper (4 labels *Submitted → AI check → Review → Published*) – each label's
`Color` is highlighted when
`Switch(galMine.Selected.Status, "submitted",1, "ai_checked",2, "in_review",3, "changes_requested",3, "editor_review",3, "published",4, "rejected",4, 0) >= <its position>`.

`galTimeline.Items`

```powerfx
Sort(Filter('Workflow Audits', Recipe.Recipe = galMine.Selected.Recipe), 'Logged On', SortOrder.Ascending)
```

Row text: `Text(ThisItem.'Logged On', "dd mmm hh:mm") & " · " & ThisItem.Action & " · " &
ThisItem.'Actor Type' & ": " & ThisItem.Actor`, plus `ThisItem.Notes`. Reviewer comments
block: `galMine.Selected.'Reviewer Comments'`.

### C9. Review queue (Reviewer / Editor only)

`scrReviewQueue.OnVisible: If(!gblIsReviewer, Navigate(scrBrowse))` (hiding the button is
not security; the Dataverse role is the real control, this just keeps the UI tidy).

```powerfx
// galQueue.Items
Filter(Recipes,
  (Status = "in_review" && 'Assigned Reviewer' = User().Email) ||
  (Status = "editor_review" && gblRole = "Editor"))
```

AI panel (clearly labelled *"AI suggestions – advisory, please verify"*): AI Summary,
`"Suggested category: " & ThisItem.'AI Category' & If(ThisItem.'AI Category' <> ThisItem.Category, " (differs from cook's choice)", "")`,
AI Tags, AI Allergens, AI Veg Conflict, AI Issues, `"Confidence: " & Text(ThisItem.'AI Confidence' * 100, "0") & "%"`,
and a red flag when `ThisItem.'AI Needs Attention'`.
*Open approval* button: `Launch("https://make.powerautomate.com/approvals/received")`
(reviewers can also answer directly in Outlook or Teams).

---

## Part D – Status model (used by the app and Flow 1)

| Status | Set by | Next |
|---|---|---|
| `draft` | App (new, imported, or edited after publishing) | `submitted` |
| `submitted` | App (*Submit for publishing*) | `ai_checked` |
| `ai_checked` | Flow 1 after AI review | `in_review` |
| `in_review` | Flow 1 (assigned to reviewer) | `changes_requested` / `rejected` / `editor_review` / `published` |
| `changes_requested` | Flow 1 (reviewer decision) | `submitted` (cook resubmits) |
| `editor_review` | Flow 1 (editor sign-off needed) | `published` / `rejected` |
| `published` | Flow 1 | `draft` (if the owner edits it) |
| `rejected` | Flow 1 | `submitted` (after changes) |

Built-in recipes are always `published`.

---

## Part E – Power Automate flows (Lab Step 4)

Create the flows **inside the solution** (Solutions → Recipe Box V6 → New → Automation →
Cloud flow), using the Dataverse connection.

### Flow 1 – `RB – Recipe publishing` (automated)

1. **Trigger** – Dataverse *When a row is added, modified or deleted*: Change type
   *Modified*, Table *Recipes*, Scope *Organization*, **Select columns** `cr_status`,
   **Filter rows** `cr_status eq 'submitted'`.
   (Both settings matter: the flow itself changes the Status many times, and without
   the filter every change would start a new run – an infinite loop.)
2. **Initialize variables**: `varEditorNeeded` (Boolean, false), `varAIOk` (Boolean, false),
   `varReviewer` (String), `varEditor` (String), `varRecipeId` = `triggerOutputs()?['body/cr_recipeid']`.
3. **List rows** *Ingredients* – Filter rows `_cr_recipe_value eq @{variables('varRecipeId')}`,
   Sort by `cr_lineno`. **Select** (map) → `if(empty(item()?['cr_amount']), item()?['cr_text'], concat(string(item()?['cr_amount']), ' ', item()?['cr_text']))`.
   Same for *Steps* → `concat(string(item()?['cr_stepno']), '. ', item()?['cr_text'])`.
   **Compose** `IngredientsText` = `join(body('Select_ingredients'), decodeUriComponent('%0A'))`, same for `StepsText`.
4. **Add a new row** *Workflow Audits*: Name `Submitted`, Recipe (lookup) `cr_recipes(@{variables('varRecipeId')})`,
   Recipe Title, Action *Submitted for publishing*, Actor = Submitted By, Actor Type `Human`,
   From `draft`, To `submitted`, Logged On `utcNow()`.
5. **Scope `Try AI review`**
   - **Run a prompt** (AI Builder) → *RB Recipe Review* with the six inputs (Title, Category,
     MarkedVegetarian = `if(triggerOutputs()?['body/cr_isveg'], 'Yes', 'No')`, Minutes,
     Ingredients = `outputs('IngredientsText')`, Steps = `outputs('StepsText')`).
   - **Parse JSON** – content: the prompt's text/JSON output; schema from
     `workflow/AI_PROMPT_RB_Recipe_Review.md`.
   - **Condition `AI output valid`**: `contains(createArray('breakfast','dinner','dessert'), body('Parse_JSON')?['suggestedCategory'])`
     is true **and** `confidence` ≥ 0 **and** ≤ 1. If no → leave `varAIOk` false and do
     nothing else here (the fallback in step 6 takes over; never terminate the run).
   - If yes → **Update a row** *Recipes* (`varRecipeId`): AI Category, AI Tags `join(body('Parse_JSON')?['tags'], ', ')`,
     AI Allergens `join(...allergens, ', ')`, AI Veg Conflict, AI Issues `join(...issues, decodeUriComponent('%0A'))`,
     AI Summary, AI Confidence, AI Needs Attention, **Status `ai_checked`**, Stage Started On `utcNow()`.
     Audit row: Action *AI review completed*, Actor *AI Builder – RB Recipe Review*, Actor Type `AI`,
     To `ai_checked`, Notes = the summary + issues. *Set variable* `varAIOk` = true.
6. **Scope `AI fallback`** – *Configure run after*: `Try AI review` **has failed / has timed out
   / is successful** and inside a **Condition** `varAIOk` is false:
   Update row → AI Summary *"AI review unavailable – full manual review required."*,
   AI Confidence 0, AI Needs Attention Yes; audit row Actor Type `System`, Action *AI unavailable – fallback*.
   (The AI is helpful but never a single point of failure.)
7. **List rows** *Reviewer Assignments* – Filter `cr_category eq '@{triggerOutputs()?['body/cr_category']}'`, Row count 1.
   Set `varReviewer` = `coalesce(first(outputs('List_reviewers')?['body/value'])?['cr_revieweremail'], parameters('RB Default Reviewer Email (kp_RBDefaultReviewerEmail)'))`,
   `varEditor` similarly. **Condition**: if `varReviewer` equals the submitter's email, use the
   default reviewer instead (nobody approves their own recipe – separation of duties).
8. **Update a row**: Status `in_review`, Assigned Reviewer `varReviewer`, Stage Started On `utcNow()`.
   Audit: *Assigned to reviewer*, Actor Type `System`, Notes = `varReviewer`.
9. **Start and wait for an approval** – Approval type **Custom Responses – Wait for one response**;
   Response options `Approve`, `Request changes`, `Reject`; Title `Review recipe: @{Title}`;
   Assigned to `varReviewer`; Item link = `@{parameters('RB App URL')}&recipeId=@{triggerOutputs()?['body/cr_recipecode']}`;
   Details (Markdown):

   ```
   **Submitted by:** {Submitted By} · **Category:** {Category} · **Veg:** {Is Veg}
   ### AI pre-check (advisory – please verify)
   - Summary: {AI Summary}
   - Suggested category: {AI Category}
   - Allergens: {AI Allergens}
   - Veg conflict: {AI Veg Conflict}
   - Issues: {AI Issues}
   - Confidence: {AI Confidence}
   ### Ingredients
   {IngredientsText}
   ### Steps
   {StepsText}
   ```
10. **Compose** `Outcome` = `body('Start_and_wait_for_an_approval')?['outcome']`,
    `Comments` = `first(body('Start_and_wait_for_an_approval')?['responses'])?['comments']`,
    `Responder` = `first(body('Start_and_wait_for_an_approval')?['responses'])?['responder']?['email']`.
    Audit row: Action `Reviewer: @{outputs('Outcome')}`, Actor = Responder, Actor Type `Human`, Notes = Comments.
11. **Switch** on `Outcome`:
    - **Request changes** → Update row Status `changes_requested`, Reviewer Comments, Stage Started On;
      **Send an email (V2)** to Submitted By: "Your recipe needs a few changes" + comments + app link.
    - **Reject** → Status `rejected`, Reviewer Comments; email with the reason.
    - **Approve** →
      **Set variable** `varEditorNeeded` =
      `or(equals(triggerOutputs()?['body/cr_source'], 'imported'), equals(variables('varAIOk'), false), less(float(coalesce(body('Parse_JSON')?['confidence'], 0)), 0.7), equals(body('Parse_JSON')?['needsHumanAttention'], true))`.
      **Condition** `varEditorNeeded`:
      - *Yes* → Status `editor_review` (+ audit, *Editor sign-off required*, Notes = which rule
        fired) → **Start and wait for an approval** (*Approve/Reject – First to respond*) assigned to
        `varEditor`, details include the reviewer's comments → audit row → if Approve → **publish**,
        else Status `rejected` + email.
      - *No* → **publish**.
    - **publish** = Update row Status `published`, Published On `utcNow()`, Stage Started On;
      audit *Published*; email the submitter "Your recipe is live in the community box".
12. Turn on **Settings → Tracked properties / run history** (default 28 days) – the run history
    is your system-level status tracking; the Workflow Audit table is the business-level one.

### Flow 2 – `RB – Review reminders` (scheduled)

Recurrence: every 1 day at 09:00 (Eastern Time). **List rows** *Recipes*, Filter
`(cr_status eq 'in_review' or cr_status eq 'editor_review') and cr_stagestartedon lt @{addHours(utcNow(), -48)}`.
**Apply to each** → Send an email to `cr_assignedreviewer` (or the editor for `editor_review`):
"Reminder: '{Title}' has been waiting more than 48 hours" with the approvals link; audit row
Actor Type `System`, Action *Reminder sent*.
*Testing tip:* temporarily change `-48` hours to `addMinutes(utcNow(), -5)` and the recurrence
to 5 minutes, then change it back and note this in your test log.

### Flow 3 – `RBDiscoverSearch` (instant, called from the app)

1. Trigger **When Power Apps calls a flow (V2)**, text input `q`.
2. **HTTP** GET `https://www.themealdb.com/api/json/v1/1/search.php?s=@{encodeUriComponent(triggerBody()['text'])}`,
   action *Settings → Timeout* `PT6S`, retry policy *None* (V5 used a 6-second timeout).
3. **Initialize variable** `meals` (Array, `[]`).
4. **Apply to each** `take(coalesce(body('HTTP')?['meals'], createArray()), 12)`
   (TheMealDB returns `{"meals": null}` when nothing matches – `coalesce` handles that):
   - **Select** From `range(1, 20)`, Map (text mode):
     `trim(concat(coalesce(items('Apply_to_each')?[concat('strMeasure', string(item()))], ''), ' ', coalesce(items('Apply_to_each')?[concat('strIngredient', string(item()))], '')))`
   - **Filter array** on the Select output: `length(item())` is greater than `0`.
   - **Append to array variable** `meals`:
     `{"id": items('Apply_to_each')?['idMeal'], "title": items('Apply_to_each')?['strMeal'], "thumb": items('Apply_to_each')?['strMealThumb'], "category": items('Apply_to_each')?['strCategory'], "area": items('Apply_to_each')?['strArea'], "instructions": items('Apply_to_each')?['strInstructions'], "source": items('Apply_to_each')?['strSource'], "ingredients": body('Filter_array')}`
   - Set the loop's **Concurrency control** to 1 so results keep their order.
5. **Respond to a PowerApp or flow** – text output `results` = `string(variables('meals'))`.
6. Add a parallel branch *Configure run after: has failed / timed out* that responds with
   `results` = `[]`, so the app shows "no results" instead of hanging.

> The HTTP action is a premium connector. It is included for development in the Developer
> Plan; if your environment blocks it, record that in the troubleshooting log and either
> build a **custom connector** for TheMealDB or leave Discover out and explain why.

---

## Part F – Version 6 integration and export (Lab Step 5)

1. Add **Flow 3** to the app (Power Automate pane). Flows 1 and 2 need no app wiring:
   they react to the data the app writes.
2. **Publish** the app, copy its web link into the `RB App URL` environment variable
   (format `https://apps.powerapps.com/play/e/<env-id>/a/<app-id>?tenantId=<tenant>`).
3. Share the app with your Reviewer and Editor test users (*Share* → add users + security role).
4. Run the tests in the documentation (section 8) and take screenshots.
5. **Export**: Solutions → Recipe Box V6 → **Export solution** → *Unmanaged* → download
   `RecipeBoxV6_1_0_0_0.zip` → put it in `app-export/`. Also *Export package (.msapp)*
   from the app editor (File → Save as → This computer) as a second copy.
6. Fill in `links.txt` and zip the folder as `Version6_KhushiPatel.zip`.
