Put your exported Power Platform files here before submitting:
  1. RecipeBoxV8_1_2_0_0.zip  (Solutions > Recipe Box V8 > Export solution > Unmanaged)
     - canvas app (now with Cook mode, Write my email, scrRecipeCard and the integration chart),
       all Dataverse tables, Flows 1-4 and environment variables.
     - Before exporting, clear the VALUE of the "RB Integration Key" environment variable
       so the secret is not inside the zip (same as V7).
  2. Recipe Box V8.msapp      (app editor > File > Save as > This computer)
Then delete this README.
