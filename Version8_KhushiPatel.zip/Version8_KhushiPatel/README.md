# The Recipe Box – Version 8 (AI-Assisted Application Development)

Version 7 (Power Apps + Dataverse + Power Automate + Make) extended with four features whose
HTML, CSS, JavaScript and Power Fx were generated with AI (Claude, Anthropic) from structured
prompts, then integrated, tested and refined.

| Use case | What the cook or editor gets | Code |
|---|---|---|
| UC1 Cook Mode | One big step at a time, tap a time to start a timer, ingredient checklist, rescaling | `web/cook-mode.html` + `web/js/cook-mode.js` |
| UC2 Email-a-Recipe composer | Builds the email Scenario A reads, checks it first with the app's rules | `web/email-composer.html` + `web/js/email-composer.js` |
| UC3 Printable recipe card | Clean card to print or copy, scaled to the chosen servings | Power Fx + HTML/CSS (HTML text control) |
| UC4 7-day integration chart | Stacked bars of OK / needs a look / failed runs per day | Power Fx + HTML/CSS (HTML text control) |

| Folder / file | Contents |
|---|---|
| `ITC6250_Version8_KhushiPatel.docx` | **Documentation:** use cases, AI prompts, integration, testing notes, reflection |
| `BUILD_GUIDE_V8.md` | Hosting (GitHub Pages) and every Power Fx formula added in V8 |
| `web/` | The two web pages, shared `css/` and `js/`, `tests/` (unit + browser tests, results, screenshots), `prototypes/` (HTML the two HTML text controls produce) |
| `docs/ai-prompts/PROMPT_LOG.md` | Full initial prompts P0–P4 and refinement prompts R1–R12 |
| `docs/diagrams/architecture_v8.png` | V8 architecture (V7 diagrams kept) |
| `app-export/` | Exported solution `Recipe Box V8` and `.msapp` |
| V7 and earlier | `BUILD_GUIDE_V7.md`, `BUILD_GUIDE_V6_base.md`, `make/`, `power-automate/`, `test-data/`, `lcnc-data/`, `workflow/` – unchanged |

Run the web tests: `cd web && bash tests/run_all.sh` (Node 18+, Python 3 + Playwright).
