# Version 8 – AI prompt log

**Tool:** Claude (Anthropic), chat on claude.ai, with code execution so generated code could be
run against tests in the same session. **Author:** Khushi Patel.

**How the prompts were made.** My first request was one line ("give me solution of version 8")
plus my V7 project zip and the lab brief. With Claude's help that was turned into the structured
prompts below, one per use case. Each uses the same six parts, because the module 10.3 readings
showed that vague prompts give generic code:

1. **Role** – who the AI should act as.
2. **Context** – the real app: tables, column names, existing formulas, colours, the V7 email template.
3. **Task** – one feature, described by what the user does.
4. **Constraints** – platform limits (HTML text control = inline styles only; no back end; no secrets in the repo), accessibility, security.
5. **Output format** – file names and what goes in each.
6. **Acceptance tests** – concrete inputs and expected outputs, so the result can be checked automatically.

Refinement prompts (R1–R12) were written only after a test failed or a screenshot showed a
problem; each names the failing test, the evidence and the expected behaviour.

---

## P0 – Shared logic (used by UC1 and UC2)

> **Role:** You are a front-end developer adding plain JavaScript to an existing Power Apps app.
>
> **Context:** The Recipe Box stores ingredients as `Amount` (decimal or blank) + `Text`. Power Fx
> `FormatQty` rounds to the nearest of 1/4, 1/3, 1/2, 2/3, 3/4 within 0.04, shows whole numbers
> below 0.02 / above 0.98 of a whole, otherwise one decimal (formula pasted below). `ParseAmount`
> reads "1 1/2", "1/4", "2". The app's form validation messages are: [pasted from V6 C5].
> The gateway cuts ingredients at 300 and steps at 600 characters; Make sends at most 40
> ingredients and 30 steps.
>
> **Task:** Write `web/js/rb-common.js` with: `formatQty`, `parseAmount`, `scaleLine`,
> `decodeRecipeHash` (reads the payload in Part C of my guide), `findTimers` (finds cooking times
> in a step sentence), `formatClock`, `cleanLine`/`splitLines` (same bullet stripping as V6),
> `validateRecipe` (same messages as the app + limits), `buildEmail` (the V7 template), `buildMailto`.
>
> **Constraints:** No libraries, no build step, works as a `<script>` tag and in Node for tests.
> Never throw on bad input – return an error code. Only accept `https://` source links.
>
> **Output:** the JS file plus `web/tests/rb-common.test.js` using `node:test`.
>
> **Acceptance tests:** formatQty(0.25)="1/4", (1.5)="1 1/2", (2.99)="3", (0.375)="0.4";
> "cook for 3 minutes"→180 s; "10-12 mins"→600–720 s; "1 hour 15 minutes"→4500 s;
> "half an hour"→1800 s; "350 degrees" and "2 cups"→no timer; a 70,000-character link→`too_long`.

## P1 – UC1 Cook Mode

> **Role:** You are a front-end developer and accessibility reviewer.
>
> **Context:** Cooks read the recipe on `scrDetail` while cooking; the screen has small text and
> no timers. The app colours are fill RGBA(255,251,245) / dark RGBA(28,25,23), text
> RGBA(41,37,36) / RGBA(245,245,244), accent #a6602b, status green/amber/red RGBA(22,163,74),
> (217,119,6), (220,38,38). Power Apps opens the page with
> `Launch(gblWebBase & "/cook-mode.html#data=" & EncodeUrl(JSON({...})))` (payload in Part C).
>
> **Task:** A full-screen Cook Mode: one step at a time in very large text; previous/next
> buttons and ←/→ keys; a progress bar; an ingredient checklist with a servings stepper that
> rescales using `formatQty`; every time phrase in a step becomes a button that starts a timer;
> several timers can run at once in a tray, with pause, cancel, and an alarm (sound, vibration,
> tab title, notification if allowed) that repeats until dismissed; "Keep screen on" using the
> Screen Wake Lock API when supported; remember the step and ticked ingredients on reload.
>
> **Constraints:** One HTML file + shared CSS + JS, no frameworks, works from GitHub Pages.
> Strict Content-Security-Policy (no inline scripts). Insert all recipe text with
> `textContent`, never `innerHTML`. Touch targets ≥ 44 px, visible focus, `aria-live` for step
> changes and alarms, respect reduced motion, no sideways scrolling at 390 px. Clear help text
> when the link is missing or broken, plus a sample recipe link.
>
> **Output:** `web/cook-mode.html`, `web/css/rb-web.css`, `web/js/cook-mode.js`, and a
> Playwright test `web/tests/e2e_cook_mode.py` using a fake clock.
>
> **Acceptance tests:** "Herb & Cheese Skillet Eggs" at 4 servings shows "8 eggs" and
> "1/2 cup grated cheese"; step text `<img src=x onerror=alert(1)>` shows as text; a 3-minute
> timer shows 3:00, 1:59 after 61 s, stays at 1:59 while paused, reaches "Done" and puts ⏰ in
> the tab title; `dark: true` gives background rgb(28, 25, 23); no console errors.

## P2 – UC2 Email-a-Recipe composer

> **Role:** You are a front-end developer who knows how the V7 Make scenario reads emails.
>
> **Context:** In V7 cooks email recipes to a Make mailhook; Gemini extracts the fields; emails
> that are missing parts are rejected (`not_a_recipe`, `invalid`). `scrEmailRecipe` only shows a
> static template (pasted below). The Gemini prompt warns about vegetarian conflicts and asks
> cooks to leave out personal details.
>
> **Task:** A guided form (name, category, minutes, serves, vegetarian, ingredients, steps,
> optional note) with a live preview of the exact template, validation with the app's own
> messages, "Open in my email app" (`mailto:` to the inbox with subject and body), "Copy email
> text", and a saved draft. Warn (do not block) about a vegetarian conflict and about email
> addresses or phone numbers in the text.
>
> **Constraints:** The inbox address arrives as `#to=` and must not stay in the address bar or
> reach any server. Show field errors only after the field is used or the cook tries to send,
> then move focus to the first problem. `mailto:` links over ~1,800 characters get cut by some
> email apps – explain and offer copy instead. Same CSP, accessibility and phone rules as P1.
>
> **Output:** `web/email-composer.html`, `web/js/email-composer.js`, `web/tests/e2e_email_composer.py`.
>
> **Acceptance tests:** the A1 test email typed with bullets produces exactly the V7 template;
> empty form + Send shows 6 errors and focuses the name; "1 tbsp fish sauce" with Vegetarian
> ticked warns about “fish sauce”; `khushi@gmail.com` is refused as the inbox; a 25-step recipe
> disables the link and copy still works.

## P3 – UC3 Printable recipe card (Power Fx + HTML/CSS)

> **Role:** You are a Power Apps maker who writes Power Fx and HTML.
>
> **Context:** Same tables and colours as above; `FormatQty`, `varRecipe`, `ddServings`,
> `varDark` exist. The Power Apps **HTML text** control accepts inline `style` attributes only –
> no `<style>`, classes or scripts.
>
> **Task:** A Power Fx formula for `htmlCard.HtmlText` that builds a recipe card: title, meta
> line, blurb, two columns (scaled ingredients, numbered method), the AI allergen notice from V6,
> and the source line for https sources; light and dark colours; plus Print, Back and a
> plain-text Copy.
>
> **Constraints:** Escape all recipe text with a named function `HtmlEsc` (replace `&` first).
> Use a table for the two columns. Must print on one Letter page and fit a 390 px phone.
>
> **Output:** the Power Fx (`BUILD_GUIDE_V8.md` Part E) and a Python generator that builds the
> same string from sample data so it can be checked in a browser.
>
> **Acceptance tests:** "Herb & Cheese Skillet Eggs" shows "&" not "&amp;"; a title containing
> `<script>` and `<b>` creates no elements; 4 servings → "8 eggs"; one printed page.

## P4 – UC4 7-day integration chart (Power Fx + HTML/CSS)

> **Role:** Same as P3.
>
> **Context:** `scrIntegrations` (V7 F5) loads `colLog` (Integration Logs, last 7 days) with
> `Status` values success, duplicate, partial, rejected, stale, failed, unauthorized.
>
> **Task:** Build `colChart` (one row per day: Ok, Warn, Bad counts) in `OnVisible`, and an
> `htmlChart.HtmlText` stacked bar chart (green OK, amber "needs a look", red failed), a count
> above each bar, day labels, a legend, and a text summary label for screen readers.
>
> **Constraints:** Inline styles only; bars scale to the busiest day (120 px), never below 3 px
> when the count is above 0; a day with no runs shows a flat line and is named in the summary.
>
> **Acceptance tests:** sample log of 16 runs over 7 days gives totals 2,3,2,3,0,4,2; the 4-run day
> is 120 px, a 2-run day 60 px; one red bar on the day with failures.

---

## Refinement prompts (after tests)

| # | Failing test / evidence | Refinement prompt (as sent) |
|---|---|---|
| R1 | U8: "Chill for half an hour" returned two timers, 30 min and 60 min | "findTimers returns both 'half an hour' and 'an hour' for the same words. When matches overlap, keep only the longer, earlier one. Keep all other U8 cases passing." |
| R2 | U15: warning said “fish” for the line "1 tbsp fish sauce" | "The vegetarian warning names 'fish' instead of 'fish sauce'. The regex alternation matches the first branch, so list multi-word phrases (fish sauce, oyster sauce, chicken stock…) before single words." |
| R3 | E1: on the help screen, *Try it with a sample recipe* did nothing (test timed out) | "The sample link only changes location.hash, and the hashchange listener is added in wireEvents(), which never runs when there is no recipe. Register it at the very start of start(). This also covers a second Launch() into an open tab." |
| R4 | E4: after pause then resume, the timer stayed at 1:59 for 120 s | "When every timer is paused, tick() clears the interval, but togglePause() never restarts it. Call ensureTicking() when a timer resumes." |
| R5 | E4: Playwright could not click *Dismiss* ("element is not stable") | "The finished-timer chip pulses with transform: scale, so its Dismiss button moves under the user's finger. Animate a box-shadow glow instead so nothing moves; keep the reduced-motion rule." |
| R6 | E6: after ticking an ingredient, ←/→ no longer changed step | "The keyboard handler ignores all INPUT elements, including checkboxes. Ignore only typing fields (text inputs, textarea, select)." |
| R7 | E10: three console errors `ERR_NAME_NOT_RESOLVED` | (No code change.) Cause: the test machine has no internet, so Google Fonts cannot load; the page falls back to system fonts as designed. Prompt: "Stub the two Google Fonts hosts in the Playwright test with an empty stylesheet so the console check only reports real page errors." |
| R8 | Screenshot `cook_phone_step2.png`: collapsed Ingredients panel left a large empty block; tapped button showed a grey highlight | "On screens ≤ 760 px set the body grid rows to auto 1fr so the collapsed details element takes only its own height; remove the tap highlight and add an :active state." |
| R9 | Screenshot: a space before the full stop after "3 minutes" | "The empty .clock span still has margin-left. Hide it when empty." |
| R10 | C2: Playwright refused to click *Open in my email app* ("element is not enabled") | "The send link has aria-disabled=true, but selecting it is how the cook sees what to fix. Screen-reader users would hear 'disabled' and never press it. Remove aria-disabled; keep href='#' and show the errors on click." |
| R11 | C8: after a reload the inbox field was empty (the address is removed from the URL) | "Keep the inbox address in sessionStorage (this tab only, cleared on close) and fill it from there after a reload. Do not use localStorage for it." |
| R12 | Screenshot `email_ready.png`: inbox `rb7x2k9q@…` displayed as `rb7×2k9q@…` | "The font's contextual alternates turn x between digits into ×. Turn off calt and ligatures for the inbox field, the To line and the email preview, so a hand-copied address is correct." |

**Verification prompt for UC3 (no bug, a check of the test itself):** "All 15 HTML checks passed
first time. Run the hostile recipe again with HtmlEsc switched off to prove the test can fail."
Result: 3 injected elements and the alert fired twice without escaping; 0 with escaping.
