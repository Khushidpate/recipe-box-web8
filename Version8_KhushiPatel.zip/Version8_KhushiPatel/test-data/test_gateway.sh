#!/usr/bin/env bash
# Test the Integration Gateway directly (before building Make).
# Usage:  GATEWAY_URL='https://...sig=...' RB_KEY='...' ./test_gateway.sh
# Replace REPLACE_WITH_REGISTERED_COOK_EMAIL in the JSON files first.
set -u
cd "$(dirname "$0")/gateway"
call () {  # $1 = file, $2 = key
  printf '\n== %s (key: %s)\n' "$1" "${2:0:4}…"
  curl -s -w '\nHTTP %{http_code}\n' -X POST "$GATEWAY_URL" \
       -H 'Content-Type: application/json' -H "x-rb-key: $2" --data @"$1"
}
call A1_createDraftFromEmail.json "$RB_KEY"   # expect 201 created
call A1_createDraftFromEmail.json "$RB_KEY"   # expect 200 duplicate (same requestId)
call A_invalid_422.json          "$RB_KEY"   # expect 200 rejected, code 422
call A5_reportEmailFailure.json  "$RB_KEY"   # expect 200 logged
call B1_upsertFeatured.json      "$RB_KEY"   # expect 200 upserted, 3 rows
call B1_upsertFeatured.json      "$RB_KEY"   # expect 200 upserted, still 3 rows
call A1_createDraftFromEmail.json "wrong-key" # expect 401 unauthorized
