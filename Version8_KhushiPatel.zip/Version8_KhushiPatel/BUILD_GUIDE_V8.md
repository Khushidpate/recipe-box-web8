# The Recipe Box – Version 8 build guide (AI-assisted features)

Version 8 = Version 7 (`BUILD_GUIDE_V7.md` and `BUILD_GUIDE_V6_base.md`, unchanged) **plus**
four features generated with AI from the prompts in `docs/ai-prompts/PROMPT_LOG.md`:

| # | Use case | Code | Where it plugs in |
|---|---|---|---|
| UC1 | Cook Mode | HTML + CSS + JavaScript (`web/cook-mode.html`) | *Cook mode* button on `scrDetail` |
| UC2 | Email-a-Recipe composer | HTML + CSS + JavaScript (`web/email-composer.html`) | *Write my email* button on `scrEmailRecipe` (V7 F3) |
| UC3 | Printable recipe card | HTML + inline CSS in an **HTML text** control | new screen `scrRecipeCard` |
| UC4 | 7-day integration chart | HTML + inline CSS in an **HTML text** control | `scrIntegrations` (V7 F5) |

No Dataverse tables, flows or Make scenarios change in V8. Build in the order below.

---

## Part A – Host the two web pages (GitHub Pages, free)

Power Apps cannot host HTML files, and the pages need no server code, so any static host
works. GitHub Pages is free and serves over HTTPS (needed for the clipboard and "keep screen on").

1. Sign in at <https://github.com> → **New repository** → name `recipe-box-web`, **Public**, *Add a README* → Create.
2. **Add file → Upload files** → drag in, from this folder's `web/`:
   `index.html`, `cook-mode.html`, `email-composer.html`, the `css` folder and the `js` folder
   (you do not need `tests/` or `prototypes/`). Commit.
3. **Settings → Pages** → Source *Deploy from a branch* → Branch `main`, folder `/ (root)` → Save.
   After about a minute the page shows the address, e.g. `https://khushipatel.github.io/recipe-box-web/`.
4. Open `…/cook-mode.html`, select *Try it with a sample recipe*, start the 3-minute timer. Then
   open `…/email-composer.html`. Both must work before you continue.
5. Put the address in `links.txt`.

The repository holds no secrets: the recipe and the inbox address are passed in the link's
`#` fragment at run time, and browsers never send the fragment to the web server.

---

## Part B – App.Formulas additions

Add under the V7 additions (`gblInbox`, `gblIsEditor`):

```powerfx
// Base address of the hosted web pages (Part A), no trailing slash
gblWebBase = "https://TO-FILL.github.io/recipe-box-web";

// Makes recipe text safe to place inside HTML. & must be replaced first.
HtmlEsc(s: Text): Text =
    Substitute(Substitute(Substitute(Substitute(Substitute(s,
        "&", "&amp;"), "<", "&lt;"), ">", "&gt;"), """", "&quot;"), "'", "&#39;");
```

(`HtmlEsc` is a user-defined function like V6's `FormatQty`; it needs **Settings → Updates →
User-defined functions** on, which you already turned on in V6.)

---

## Part C – UC1 Cook Mode button (`scrDetail`)

Add a button `btnCookMode`, text **Cook mode**, next to *Add to list*:

```powerfx
// btnCookMode.Visible
CountRows(galSteps.AllItems) > 0

// btnCookMode.OnSelect
Launch(gblWebBase & "/cook-mode.html#data=" & EncodeUrl(JSON({
    v: 1,
    t: varRecipe.Title,
    b: varRecipe.'Base Servings',
    s: Value(ddServings.Selected.Value),
    u: Coalesce(varRecipe.'Serving Unit Label', "serving"),
    i: ForAll(Sort(Filter(Ingredients, Recipe.Recipe = varRecipe.Recipe), 'Line No') As ing,
              {a: ing.Amount, x: ing.Text}),
    st: ForAll(Sort(Filter(Steps, Recipe.Recipe = varRecipe.Recipe), 'Step No') As stp,
               {x: stp.Text}),
    src: Coalesce(varRecipe.'Source Url', ""),
    dark: varDark
}, JSONFormat.Compact)))
```

- `JSON()` writes a blank `Amount` as `null`; the page shows those lines unscaled ("salt and
  pepper"), exactly like the app does.
- The page uses the same rounding as `FormatQty`, so 4 servings shows the same amounts in the
  app and in Cook Mode (tested: `web/tests/rb-common.test.js` U1, U3).
- Payload contract (`v: 1`): `t` title, `b` base servings, `s` chosen servings, `u` unit label,
  `i` ingredients `{a amount|null, x text}`, `st` steps `{x text}`, `src` https source link,
  `dark` theme. The page also accepts `[{"Value": "..."}]` tables in case you build `i`/`st`
  from a single-column table instead.

---

## Part D – UC2 Email-a-Recipe composer (`scrEmailRecipe`)

Keep the V7 template label as a fallback and add, above it, a primary button `btnCompose`,
text **Write my email**:

```powerfx
// btnCompose.OnSelect
Launch(gblWebBase & "/email-composer.html#to=" & EncodeUrl(gblInbox) &
       "&theme=" & If(varDark, "dark", "light"))
```

The page reads the inbox address, removes it from the address bar, checks the recipe with the
app's own validation messages (title, category, minutes 1–1440, servings 1–50, ingredients
and steps), plus the gateway/Make limits (40 ingredients, 30 steps, 300/600 characters), warns
about vegetarian conflicts and personal details, and builds the email in the V7 F3 template.
*Open in my email app* uses a `mailto:` link; *Copy email text* is the fallback for long recipes.

---

## Part E – UC3 Printable recipe card (new screen `scrRecipeCard`)

1. On `scrDetail` add a button **Recipe card**:
   `OnSelect = Set(varCardServings, Value(ddServings.Selected.Value)); Navigate(scrRecipeCard, ScreenTransition.None)`
2. New screen `scrRecipeCard`, Fill as the other screens. Header: *Back*
   (`Back()`), *Print* (`Print()`), *Copy text* (below).
3. Insert → **HTML text** → `htmlCard`, X 20, Width `Parent.Width - 40`, `Fill = Transparent`,
   **Auto height** On (if your version has no Auto height, set Height 900 and put the control in
   a vertical container with *Vertical overflow = Scroll*).

```powerfx
// htmlCard.HtmlText
With({n: varCardServings, base: varRecipe.'Base Servings',
      ink:    If(varDark, "#f5f5f4", "#292524"),
      muted:  If(varDark, "#b5ada6", "#6b635c"),
      paper:  If(varDark, "#262220", "#ffffff"),
      line:   If(varDark, "#3d3733", "#e7dfd3"),
      accent: If(varDark, "#e0a06a", "#a6602b"),
      note:   If(varDark, "#3a2e14", "#fdf1e0")},
  "<div style='font-family:Segoe UI,Arial,sans-serif;color:" & ink & ";background:" & paper &
    ";border:1px solid " & line & ";border-radius:12px;padding:20px 24px;max-width:760px'>" &
  "<div style='font-size:24px;font-weight:700;line-height:1.25'>" & HtmlEsc(varRecipe.Title) & "</div>" &
  "<div style='color:" & muted & ";font-size:14px;margin:6px 0 14px'>" &
    HtmlEsc(Proper(varRecipe.Category)) & " &middot; " & HtmlEsc(varRecipe.'Time Label') &
    " &middot; serves " & n & If(varRecipe.'Is Veg', " &middot; vegetarian", "") & "</div>" &
  If(IsBlank(varRecipe.Blurb), "",
    "<p style='margin:0 0 16px;font-size:15px;line-height:1.5'>" & HtmlEsc(varRecipe.Blurb) & "</p>") &
  "<table role='presentation' style='width:100%;border-collapse:collapse'><tr>" &
  "<td style='vertical-align:top;width:38%;padding:0 20px 0 0'>" &
    "<div style='font-weight:700;color:" & accent & ";margin-bottom:6px'>Ingredients</div>" &
    "<ul style='margin:0;padding-left:18px;font-size:15px;line-height:1.6'>" &
    Concat(Sort(Filter(Ingredients, Recipe.Recipe = varRecipe.Recipe), 'Line No'),
      "<li>" & HtmlEsc(If(IsBlank(ThisRecord.Amount), ThisRecord.Text,
                          FormatQty(ThisRecord.Amount * n / base) & " " & ThisRecord.Text)) & "</li>") &
    "</ul></td>" &
  "<td style='vertical-align:top;border-left:1px solid " & line & ";padding:0 0 0 20px'>" &
    "<div style='font-weight:700;color:" & accent & ";margin-bottom:6px'>Method</div>" &
    "<ol style='margin:0;padding-left:20px;font-size:15px;line-height:1.5'>" &
    Concat(Sort(Filter(Steps, Recipe.Recipe = varRecipe.Recipe), 'Step No'),
      "<li style='margin-bottom:8px'>" & HtmlEsc(ThisRecord.Text) & "</li>") &
    "</ol></td></tr></table>" &
  If(IsBlank(varRecipe.'AI Allergens'), "",
    "<div style='margin-top:16px;padding:8px 12px;border-left:4px solid #b45309;background:" & note &
    ";font-size:13px'>Contains (AI-suggested, checked by a reviewer): " & HtmlEsc(varRecipe.'AI Allergens') &
    ". Always check labels yourself.</div>") &
  If(StartsWith(varRecipe.'Source Url', "https://"),
    "<div style='margin-top:12px;font-size:12px;color:" & muted & "'>Source: " &
    HtmlEsc(varRecipe.'Source Url') & "</div>", "") &
  "</div>")
```

```powerfx
// btnCardCopy.OnSelect – plain-text version for messages
Copy(varRecipe.Title & Char(10) & "Serves " & varCardServings & Char(10) & Char(10) &
  Concat(Sort(Filter(Ingredients, Recipe.Recipe = varRecipe.Recipe), 'Line No'),
    "- " & If(IsBlank(ThisRecord.Amount), ThisRecord.Text,
              FormatQty(ThisRecord.Amount * varCardServings / varRecipe.'Base Servings') & " " & ThisRecord.Text), Char(10)) &
  Char(10) & Char(10) &
  Concat(Sort(Filter(Steps, Recipe.Recipe = varRecipe.Recipe), 'Step No'), ThisRecord.'Step No' & ". " & ThisRecord.Text, Char(10)));
Notify("Recipe copied", NotificationType.Success)
```

Why the rules: the HTML text control accepts **inline styles only** (no `<style>` block, no
classes, no scripts), so every style is inline and the two-column layout is a table, which the
control renders reliably. All recipe text goes through `HtmlEsc` – a title such as
`Herb & Cheese Skillet Eggs` or text containing `<` must not break the markup.

---

## Part F – UC4 7-day integration chart (`scrIntegrations`)

1. Append to `scrIntegrations.OnVisible` (after the V7 `ClearCollect(colLog, …)`):

```powerfx
ClearCollect(colChart,
  ForAll(Sequence(7) As s,
    With({d0: DateAdd(Today(), s.Value - 7, TimeUnit.Days)},
      With({dayRows: Filter(colLog, 'Logged On' >= d0 && 'Logged On' < DateAdd(d0, 1, TimeUnit.Days))},
        {DayStart: d0,
         Ok:   CountRows(Filter(dayRows, Status in ["success", "duplicate"])),
         Warn: CountRows(Filter(dayRows, Status in ["partial", "rejected", "stale"])),
         Bad:  CountRows(Filter(dayRows, Status in ["failed", "unauthorized"]))}))))
```

(The column is called `DayStart`, not `Day`, because `Day()` is a Power Fx function.)

2. Insert → **HTML text** → `htmlChart` between the two status tiles and `galFailures`,
   Width `Parent.Width - 40`, Height 220, `Fill = Transparent`.

```powerfx
// htmlChart.HtmlText
With({h: 120, mx: Max(Max(colChart, Ok + Warn + Bad), 1),
      ink:   If(varDark, "#f5f5f4", "#292524"),
      muted: If(varDark, "#b5ada6", "#6b635c"),
      line:  If(varDark, "#3d3733", "#e7dfd3")},
  "<div style='font-family:Segoe UI,Arial,sans-serif;color:" & ink & "'>" &
  "<table role='presentation' style='width:100%;border-collapse:collapse;table-layout:fixed'><tr>" &
  Concat(colChart,
    "<td style='vertical-align:bottom;text-align:center;height:" & (h + 24) & "px;padding:0 6px;border-bottom:1px solid " & line & "'>" &
    "<div style='font-size:12px;color:" & muted & ";margin-bottom:3px'>" & (Ok + Warn + Bad) & "</div>" &
    If(Bad > 0,  "<div style='height:" & Max(Round(Bad / mx * h, 0), 3)  & "px;background:#dc2626'></div>", "") &
    If(Warn > 0, "<div style='height:" & Max(Round(Warn / mx * h, 0), 3) & "px;background:#d97706'></div>", "") &
    If(Ok > 0,   "<div style='height:" & Max(Round(Ok / mx * h, 0), 3)   & "px;background:#16a34a'></div>", "") &
    If(Ok + Warn + Bad = 0, "<div style='height:2px;background:" & line & "'></div>", "") &
    "</td>") &
  "</tr><tr>" &
  Concat(colChart, "<td style='text-align:center;font-size:12px;color:" & muted & ";padding-top:6px'>" &
                   Text(DayStart, "ddd d") & "</td>") &
  "</tr></table>" &
  "<div style='font-size:12px;color:" & muted & ";margin-top:10px'>" &
    "<span style='display:inline-block;width:10px;height:10px;background:#16a34a;margin:0 5px 0 0;vertical-align:middle'></span>OK" &
    "<span style='display:inline-block;width:10px;height:10px;background:#d97706;margin:0 5px 0 14px;vertical-align:middle'></span>Needs a look" &
    "<span style='display:inline-block;width:10px;height:10px;background:#dc2626;margin:0 5px 0 14px;vertical-align:middle'></span>Failed" &
  "</div></div>")
```

3. Screen readers cannot read a picture of bars, so add a label `lblChartSummary` under it:

```powerfx
// lblChartSummary.Text
"Last 7 days: " & Sum(colChart, Ok) & " OK, " & Sum(colChart, Warn) & " needing a look, " &
Sum(colChart, Bad) & " failed runs." &
If(CountRows(Filter(colChart, Ok + Warn + Bad = 0)) > 0,
   " No runs on " & Concat(Filter(colChart, Ok + Warn + Bad = 0), Text(DayStart, "ddd d"), ", ") & ".", "")
```

A day with no runs at all is worth noticing (the daily feed should run every day), so the
summary names those days.

---

## Part G – Test, export, submit

1. Web pages, automatic (optional, on your computer): from `web/` run `bash tests/run_all.sh`
   (Node 18+, Python 3 with `pip install playwright` and `playwright install chromium`).
   Results from my run are in `web/tests/*_results.json` and `web/tests/screenshots/`.
2. In-app tests T-01 to T-12 from the documentation: run them in Power Apps and record results
   and screenshots.
3. Export: Solutions → **Clone solution** `Recipe Box V8`, version `1.2.0.0` (or bump the version)
   → Export → Unmanaged → `RecipeBoxV8_1_2_0_0.zip` into `app-export/`, plus the `.msapp`.
4. Fill `links.txt`, check the documentation, zip the folder as `Version8_KhushiPatel.zip`.
