# Scenario B – `RB-B Daily Inspiration` (Make, scheduled)

**Use case:** external API data fetching. **Trigger:** schedule, every day 06:00
(organization timezone America/Toronto). **Output:** today's 3 Featured Recipe rows in
Dataverse, via the Integration Gateway. Formulas: `BUILD_GUIDE_V7.md` Part E.

![Scenario B](../docs/diagrams/scenarioB_daily_inspiration.png)

| # | Module | Purpose | On error | Credits/day |
|---|---|---|---|---|
| 1 | JSON › Parse JSON | Fixed slot list (breakfast / dinner rotation / dessert) | default | 1 |
| 2 | Flow control › Iterator | One bundle per slot | – | 1 |
| 3 | HTTP › Make a request | `GET filter.php?c=…` meal list for the category | **Break**, 2 attempts, 1 min | 3 |
| F | Filter *Has meals* | `length(meals) > 0` – a failed or empty category is skipped | – | 0 |
| 4 | HTTP › Make a request | `GET lookup.php?i=…` full meal; pick rotates by day of year | **Break**, 2 attempts, 1 min | 3 |
| 5 | JSON › Create JSON | Transform to `rb_featured_meal` (see table) | default | 3 |
| 6 | Tools › Text aggregator | Join meals into one JSON array, count bundles | – | 1 |
| 7 | HTTP › Make a request | POST `upsertFeatured` (one batched call, `partial` if < 3) | **Break**, 3 attempts, 15 min | 1 |
| 8 | Data store › Add/replace a record | Ledger `daily-<date>` with the reply status | default | 1 |

**Total:** 14 credits/day ≈ 434/month (31 days).

## Transformation (module 5)

| Target field | Rule | Why |
|---|---|---|
| title | first 80 characters of `strMeal` | Matches app column and card layout |
| appCategory | the slot (`breakfast` / `dinner` / `dessert`) | TheMealDB categories (Beef, Seafood…) do not match the app's 3 categories |
| isVeg | `strCategory` contains Vegetarian or Vegan | Same rule as V5/V6 import |
| thumb | kept only if it starts with `https://` | Power Apps image control and CSP-safe |
| instructions | `\r\n` → newline, first 4,000 characters | Splits into steps in the app; fits the column |
| ingredientLines | 20 measure + ingredient pairs, one per line | TheMealDB stores ingredients as 40 separate fields |
| sourceUrl | `strSource`, else the TheMealDB meal page | Attribution is never empty (copyright governance from V6) |

## Pick rotation

`index = ((day of year + slot offset) mod number of meals) + 1` – deterministic, so a re-run
on the same day picks the same meals (idempotent with the gateway's Feature Date + Slot key)
and consecutive days step through the list without repeats. Dinner rotates its category by
weekday: Mon Chicken, Tue Beef, Wed Pasta, Thu Seafood, Fri Vegetarian, Sat Lamb, Sun Pork.
