# Scenario A – `RB-A Email-to-Recipe` (Make, instant)

**Use case:** email parsing and processing. **Trigger:** custom mailhook (instant).
**Output:** a draft Recipe (+ Ingredients, Steps) owned by the sender in Dataverse, via the
Integration Gateway. Formulas: `BUILD_GUIDE_V7.md` Part D.

![Scenario A](../docs/diagrams/scenarioA_email_to_recipe.png)

| # | Module | Purpose | On error | Credits |
|---|---|---|---|---|
| 1 | Webhooks › Custom mailhook | Receive the email (sender, subject, text, html) | – | 1 |
| 2 | Data store › Check the existence of a record | Idempotency: has this email been seen? | default (run fails, Make alerts) | 1 |
| F | Filter *New email only* | `Exists = false` | – | 0 |
| 3 | Data store › Add/replace a record | Ledger: `received` | default | 1 |
| 4 | Text parser › HTML to text | Plain text for the AI | default | 1 |
| 5 | Google Gemini AI › Extract structured data | Free text → recipe fields (`gemini_extract_prompt.md`, `gemini_output_schema.json`) | **Error route:** HTTP `reportEmailFailure` (`ai_failed`) → ledger `needs_template` → **Ignore** | 1 |
| 6 | Tools › Set multiple variables | Normalise category, minutes, servings, title; compute `isValid`, `reason` | default | 1 |
| 7 | JSON › Create JSON | Gateway request (`createDraftFromEmail` or `reportEmailFailure`), safe escaping | default | 1 |
| 8 | HTTP › Make a request | POST to gateway, header `x-rb-key` from keychain, parse JSON reply | **Error route:** ledger `retrying` → **Break** (3 attempts, 15 min, auto-complete) | 1 |
| R | Router on `8.data.status` | `created` / `duplicate` / `rejected` / fallback (`logged`) | – | 0 |
| 9 | Data store › Update a record (one per route) | Ledger final status + recipe code or reason | default | 1 |

**Total:** 9 credits per new email; 2 credits for a duplicate (stops at the filter).

## Scenario settings

| Setting | Value | Why |
|---|---|---|
| Sequential processing | Yes | Emails are processed in arrival order; a retry does not overtake a newer email |
| Allow storing of incomplete executions | Yes | Required for Break; a failed run waits to be retried or resumed instead of being lost |
| Number of consecutive errors | 3 | Make deactivates the scenario after 3 straight failures and emails me (protects credits) |
| Data is confidential | Yes | Hides email content in execution logs from other organization members |

## What the gateway replies

| `status` | Meaning | Ledger status |
|---|---|---|
| `created` | Draft created, cook emailed a deep link | `created` |
| `duplicate` | A recipe with this Intake Ref already exists | `duplicate` |
| `rejected` | Sender not registered (code 403) or validation failed (code 422) | `rejected_by_app` |
| `logged` | `reportEmailFailure` handled; template emailed if sender is registered | `needs_template` |
| HTTP 400 / 401 / 429 / 5xx / timeout | Technical failure | `retrying` → Break |
