Put the exported Make blueprints here before submitting:
  RB-A_Email_to_Recipe.blueprint.json    (Scenario A > ... > Export blueprint)
  RB-B_Daily_Inspiration.blueprint.json  (Scenario B > ... > Export blueprint)
Blueprints contain the modules, filters, error handlers and mappings, but no
connections, API keys or keychain values. Delete this README afterwards.
