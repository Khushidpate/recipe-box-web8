# The Recipe Box – Version 7 build guide (Make + Power Platform)

Version 7 = Version 6 (see `BUILD_GUIDE_V6_base.md`, unchanged) **plus** two Make
scenarios, one new Power Automate flow (the Integration Gateway), two new Dataverse
tables, three new Recipe columns and three app changes. Build in the order below;
each part is testable on its own.

> **Names.** As in V6, `cr_` stands for your publisher prefix (e.g. `kp_`). Make module
> numbers (`1.`, `4.` …) are assigned in the order you add modules, so add them in the
> order listed here and the formulas will match. If a number differs, re-map the field
> from the mapping panel instead of typing it.

---

## Part A – Power Platform: tables, columns, environment variables

Work inside a new solution version: **Solutions → Recipe Box V6 → ⋯ → Clone solution**
→ name `Recipe Box V7`, version `1.1.0.0` (or keep one solution and bump the version).

### A1. New columns on **Recipe**

| Column | Type | Notes |
|---|---|---|
| Intake Channel | Text 20 | `app` (default) / `email` / `discover` / `featured` |
| Intake Ref | Text 120 | `mail-<hash>` for email drafts; add a **key** on it (Keys → New key) so duplicates are impossible at database level |
| Import Notes | Multi 2000 | AI confidence + warnings from email parsing |

Update the V6 Discover import formula (V6 guide C7) to also set `'Intake Channel': "discover"`,
and V6 btnSave (C5) to set `'Intake Channel': If(isNew, "app", varEdit.'Intake Channel')`.

### A2. New table **Featured Recipe** (plural *Featured Recipes*) – primary column *Title* (Text 120)

| Column | Type | Notes |
|---|---|---|
| Feature Date | Text 10 | `YYYY-MM-DD` (Toronto). Text, not Date, so the gateway can match it exactly |
| Slot | Text 20 | `breakfast` / `dinner` / `dessert` |
| Meal Id | Text 20 | TheMealDB `idMeal` |
| App Category | Text 20 | same values as Recipe.Category |
| Meal Category | Text 60 | TheMealDB category (e.g. Seafood) |
| Area | Text 60 | |
| Is Veg | Yes/No | |
| Thumbnail Url | Text 500 | |
| Ingredient Lines | Multi 4000 | one `measure ingredient` per line |
| Instructions | Multi 4000 | |
| Source Url | Text 500 | attribution |
| Is Active | Yes/No | only today's rows are active |

Add a **key** on *Feature Date + Slot*.

### A3. New table **Integration Log** – primary column *Request Id* (Text 120)

| Column | Type | Notes |
|---|---|---|
| Integration | Text 30 | `email_intake` / `daily_feed` / `monitor` / `gateway` |
| Action | Text 50 | gateway action name |
| Status | Text 20 | `success` / `duplicate` / `rejected` / `partial` / `failed` / `unauthorized` / `stale` |
| Http Status | Whole number | status code returned (or the business code: 403, 422) |
| Make Execution Id | Text 100 | correlation ID |
| Records Affected | Whole number | |
| Detail | Multi 4000 | reason or error text – **never the email body** |
| Sender | Text 200 | email intake only |
| Duration Ms | Whole number | |
| Logged On | Date and time | |

Security: give the **RB Reviewer** role (copied in V6 B5) Organization-level **Read** on
Integration Log so Editors can see the monitor; Cooks get no access to this table.

### A4. Environment variables (Text) in the solution

| Name | Value |
|---|---|
| `RB Integration Key` | a long random string, e.g. from `python3 -c "import secrets;print(secrets.token_urlsafe(32))"` |
| `RB Admin Email` | your address (alerts) |
| `RB Recipe Inbox` | the Make mailhook address (fill after Part C1) |

V6 variables `RB Default Reviewer Email` and `RB App URL` are reused.

---

## Part B – Flow 4: `RB – Integration Gateway` (Power Automate)

Full step list with expressions: `power-automate/RB_Integration_Gateway.md`.
Request contract: `power-automate/gateway_request.schema.json` and
`power-automate/gateway_contract.md`. Build and test it with `test-data/gateway/*.json`
and `test-data/test_gateway.sh` **before** building Make – then Make only has to send the
same JSON.

After saving, copy the trigger's **HTTP POST URL** (it contains a `sig=` signature – treat
it as a secret). Set **Who can trigger the flow** = *Anyone* (the key header and the `sig`
protect it).

---

## Part C – Make setup

1. Sign up at <https://www.make.com> (Free plan). Organization timezone **America/Toronto**
   (Organization → Settings), otherwise "06:00" and `formatDate(now…)` use UTC.
2. **Keychain** (left menu → Keys → Add): type *API key*, name `RB gateway key`,
   key = value of `RB Integration Key`, placement *In the header*, parameter name `x-rb-key`.
3. **Data structure** `rb_ledger` (Data structures → Add) – fields (all Text unless stated):
   `scenario`, `status`, `sender`, `subject`, `recipeCode`, `detail`, `executionId`,
   `startedAt` (Date), `finishedAt` (Date). JSON copy: `make/ledger_data_structure.json`.
4. **Data store** `rb_integration_ledger` using `rb_ledger` (the Free plan allows one, 1 MB).
5. **Google Gemini AI connection**: get a key at <https://aistudio.google.com> → *Get API key*;
   in Make add any Gemini module → *Create a connection* → paste the key.
6. Profile → **Notifications**: turn on email for *Errors and warnings*.

---

## Part D – Scenario A `RB-A Email-to-Recipe`

Full module-by-module table: `make/RB-A_Email_to_Recipe.md`. Key settings and formulas:

**Module 1 – Webhooks › Custom mailhook.** Create → copy the address
(`…@hook.<zone>.make.com`) into env variable `RB Recipe Inbox` and the app (Part F1).

**Module 2 – Data store › Check the existence of a record.** Key:

```
mail-{{md5(lower(1.sender.address) + "|" + 1.subject + "|" + 1.text)}}
```

**Filter 2→3 "New email only":** `Exists` (from module 2) *Equal to (boolean)* `false`.

**Module 3 – Data store › Add/replace a record.** Same key; scenario `email_intake`,
status `received`, sender `{{1.sender.address}}`, subject `{{1.subject}}`,
executionId = *System variables › Execution ID* (mapping panel), startedAt `{{now}}`.

**Module 4 – Text parser › HTML to text.** HTML: `{{ifempty(1.html; 1.text)}}`.

**Module 5 – Google Gemini AI › Extract structured data** (model *gemini-2.5-flash*).
Instructions: copy from `make/gemini_extract_prompt.md`. Text to analyse:
`<email>{{substring(4.text; 0; 8000)}}</email>`. Output fields exactly as listed in
`make/gemini_output_schema.json` (isRecipe, title, category, minutes, servings, isVeg, blurb,
ingredients[{amount, text}], steps[], confidence, warnings[]).
*If your account only offers "Generate a response":* paste the same prompt, ask for JSON,
then add **JSON › Parse JSON** with the schema file (+1 credit per email).

**Error-handler route on module 5** (right-click → *Add error handler*):
1. **HTTP › Make a request** – same URL/auth/settings as module 8, raw JSON body (all fields
   are safe to place without escaping):
   ```json
   {"action":"reportEmailFailure","requestId":"mail-{{md5(lower(1.sender.address) + "|" + 1.subject + "|" + 1.text)}}",
    "integration":"email_intake","makeExecutionId":"<System variables › Execution ID>","sentAt":"{{now}}",
    "payload":{"senderEmail":"{{lower(1.sender.address)}}","reason":"ai_failed","detail":"Gemini module error"}}
   ```
2. **Data store › Update a record** – status `needs_template`, finishedAt `{{now}}`.
3. **Ignore** directive.

**Module 6 – Tools › Set multiple variables**

| Variable | Value |
|---|---|
| `title` | `{{substring(ifempty(trim(5.title); 1.subject); 0; 120)}}` |
| `category` | `{{switch(lower(5.category); "breakfast"; "breakfast"; "dessert"; "dessert"; "dinner")}}` |
| `minutes` | `{{if(5.minutes >= 1 & 5.minutes <= 1440; round(5.minutes); emptystring)}}` |
| `servings` | `{{if(5.servings >= 1 & 5.servings <= 50; round(5.servings); 2)}}` |
| `isValid` | `{{5.isRecipe & length(trim(ifempty(5.title; 1.subject))) > 0 & length(5.ingredients) > 0 & length(5.steps) > 0}}` |
| `reason` | `{{if(5.isRecipe; "invalid"; "not_a_recipe")}}` |

(The and-operator `&` is in the *General functions* panel; insert it from there if typing it
does not turn it into an operator.)

**Module 7 – JSON › Create JSON** with data structure `rb_gateway_request`
(generate it in Make from `test-data/gateway/A1_createDraftFromEmail.json` → *Generate*).
Create JSON escapes quotes and line breaks in the email text for you – that is why it is used
instead of typing a raw body.

| Field | Value |
|---|---|
| action | `{{if(6.isValid; "createDraftFromEmail"; "reportEmailFailure")}}` |
| requestId | `mail-{{md5(lower(1.sender.address) + "|" + 1.subject + "|" + 1.text)}}` |
| integration | `email_intake` |
| makeExecutionId | *System variables › Execution ID* |
| sentAt | `{{now}}` |
| payload.senderEmail | `{{lower(1.sender.address)}}` |
| payload.subject | `{{1.subject}}` |
| payload.reason | `{{if(6.isValid; emptystring; 6.reason)}}` |
| payload.detail | `{{join(5.warnings; "; ")}}` |
| payload.recipe.title / category / minutes / servings | `6.title`, `6.category`, `6.minutes`, `6.servings` |
| payload.recipe.isVeg | `{{ifempty(5.isVeg; false)}}` |
| payload.recipe.blurb | `{{substring(ifempty(5.blurb; "Sent by email."); 0; 300)}}` |
| payload.recipe.ingredients | `{{slice(5.ingredients; 0; 40)}}` (map the whole array) |
| payload.recipe.steps | `{{slice(5.steps; 0; 30)}}` |
| payload.ai.confidence | `{{ifempty(5.confidence; 0)}}` |
| payload.ai.warnings | `5.warnings` (whole array) |

**Module 8 – HTTP › Make a request**
- URL: the gateway HTTP POST URL · Method **POST**
- Authentication: *API key* → keychain `RB gateway key` (adds header `x-rb-key`)
- Body: *Raw*, content type *JSON (application/json)*, content `{{7.json}}`
- Parse response **Yes** · Timeout **40** s · *Evaluate all states as errors* **Yes**

**Error handler on module 8:** Data store › Update a record (status `retrying`) → **Break**
(*Automatically complete execution* Yes, *Number of attempts* 3, *Interval between attempts* 15 min).

**Router after module 8**, one route per reply `{{8.data.status}}`, each ending in
**Data store › Update a record** (module 9, same key, finishedAt `{{now}}`):

| Route filter | Ledger status | Other ledger fields |
|---|---|---|
| `created` | `created` | recipeCode `{{8.data.recipeCode}}` |
| `duplicate` | `duplicate` | recipeCode `{{8.data.recipeCode}}` |
| `rejected` | `rejected_by_app` | detail `{{8.data.message}}` |
| `logged` (fallback) | `needs_template` | detail `{{8.data.message}}` |

**Scenario settings** (⋯ → Scenario settings): Sequential processing **Yes**; Allow storing of
incomplete executions **Yes**; Number of consecutive errors **3**. Scheduling *Immediately*, **ON**.

Credits per email: modules 1–8 + one ledger update = **9**.

---

## Part E – Scenario B `RB-B Daily Inspiration`

Full table: `make/RB-B_Daily_Inspiration.md`.

**Schedule:** *Every day* at **06:00**.

**Module 1 – JSON › Parse JSON** (data structure: generate from this sample):

```json
[{"slot":"breakfast","c":"Breakfast","offset":0},
 {"slot":"dinner","c":"ROTATE","offset":7},
 {"slot":"dessert","c":"Dessert","offset":13}]
```

**Module 2 – Flow control › Iterator** over module 1's array.

**Module 3 – HTTP › Make a request** GET
`https://www.themealdb.com/api/json/v1/1/filter.php?c={{if(2.c = "ROTATE"; get(split("Chicken,Beef,Pasta,Seafood,Vegetarian,Lamb,Pork"; ","); formatDate(now; "E")); 2.c)}}`
Parse response Yes, timeout 10. Error handler: **Break**, 2 attempts, 1 min.

**Filter 3→4 "Has meals":** `{{length(3.data.meals)}}` *Greater than* `0`.

**Module 4 – HTTP › Make a request** GET
`https://www.themealdb.com/api/json/v1/1/lookup.php?i={{get(map(3.data.meals; "idMeal"); ((formatDate(now; "DDD") + 2.offset) mod length(3.data.meals)) + 1)}}`
Parse response Yes, timeout 10. Error handler: **Break**, 2 attempts, 1 min.

**Module 5 – JSON › Create JSON**, data structure `rb_featured_meal`
(`make/featured_meal_data_structure.json`):

| Field | Value |
|---|---|
| slot | `{{2.slot}}` |
| mealId | `{{4.data.meals[1].idMeal}}` |
| title | `{{substring(4.data.meals[1].strMeal; 0; 80)}}` |
| appCategory | `{{2.slot}}` |
| mealCategory | `{{4.data.meals[1].strCategory}}` |
| area | `{{4.data.meals[1].strArea}}` |
| isVeg | `{{contains(lower(4.data.meals[1].strCategory); "vegetarian") | contains(lower(4.data.meals[1].strCategory); "vegan")}}` |
| thumb | `{{if(startswith(4.data.meals[1].strMealThumb; "https://"); 4.data.meals[1].strMealThumb; emptystring)}}` |
| instructions | `{{substring(replace(4.data.meals[1].strInstructions; "/\r\n?/g"; newline); 0; 4000)}}` |
| ingredientLines | the 20-pair template below |
| sourceUrl | `{{ifempty(4.data.meals[1].strSource; "https://www.themealdb.com/meal/" + 4.data.meals[1].idMeal)}}` |

`ingredientLines` (paste as one line; the gateway drops blank lines):

```
{{trim(4.data.meals[1].strMeasure1)}} {{trim(4.data.meals[1].strIngredient1)}}{{newline}}{{trim(4.data.meals[1].strMeasure2)}} {{trim(4.data.meals[1].strIngredient2)}}{{newline}}{{trim(4.data.meals[1].strMeasure3)}} {{trim(4.data.meals[1].strIngredient3)}}{{newline}}{{trim(4.data.meals[1].strMeasure4)}} {{trim(4.data.meals[1].strIngredient4)}}{{newline}}{{trim(4.data.meals[1].strMeasure5)}} {{trim(4.data.meals[1].strIngredient5)}}{{newline}}{{trim(4.data.meals[1].strMeasure6)}} {{trim(4.data.meals[1].strIngredient6)}}{{newline}}{{trim(4.data.meals[1].strMeasure7)}} {{trim(4.data.meals[1].strIngredient7)}}{{newline}}{{trim(4.data.meals[1].strMeasure8)}} {{trim(4.data.meals[1].strIngredient8)}}{{newline}}{{trim(4.data.meals[1].strMeasure9)}} {{trim(4.data.meals[1].strIngredient9)}}{{newline}}{{trim(4.data.meals[1].strMeasure10)}} {{trim(4.data.meals[1].strIngredient10)}}{{newline}}{{trim(4.data.meals[1].strMeasure11)}} {{trim(4.data.meals[1].strIngredient11)}}{{newline}}{{trim(4.data.meals[1].strMeasure12)}} {{trim(4.data.meals[1].strIngredient12)}}{{newline}}{{trim(4.data.meals[1].strMeasure13)}} {{trim(4.data.meals[1].strIngredient13)}}{{newline}}{{trim(4.data.meals[1].strMeasure14)}} {{trim(4.data.meals[1].strIngredient14)}}{{newline}}{{trim(4.data.meals[1].strMeasure15)}} {{trim(4.data.meals[1].strIngredient15)}}{{newline}}{{trim(4.data.meals[1].strMeasure16)}} {{trim(4.data.meals[1].strIngredient16)}}{{newline}}{{trim(4.data.meals[1].strMeasure17)}} {{trim(4.data.meals[1].strIngredient17)}}{{newline}}{{trim(4.data.meals[1].strMeasure18)}} {{trim(4.data.meals[1].strIngredient18)}}{{newline}}{{trim(4.data.meals[1].strMeasure19)}} {{trim(4.data.meals[1].strIngredient19)}}{{newline}}{{trim(4.data.meals[1].strMeasure20)}} {{trim(4.data.meals[1].strIngredient20)}}{{newline}}
```

**Module 6 – Tools › Text aggregator** – source module: Iterator (2); text `{{5.json}}`;
row separator *Other* → `,`.

**Module 7 – HTTP › Make a request** POST gateway, API key auth, JSON raw body:

```json
{
  "action": "upsertFeatured",
  "requestId": "daily-{{formatDate(now; "YYYY-MM-DD")}}",
  "integration": "daily_feed",
  "makeExecutionId": "<System variables › Execution ID>",
  "sentAt": "{{now}}",
  "payload": {
    "featureDate": "{{formatDate(now; "YYYY-MM-DD")}}",
    "partial": {{6.__IMTAGGLENGTH__ < 3}},
    "meals": [{{6.text}}]
  }
}
```

(`__IMTAGGLENGTH__` is the aggregator's *Bundles count* output – map it from the panel. The `meals` text is already valid JSON from Create JSON, so this body can be typed raw.)
Parse response Yes; evaluate states as errors Yes. Error handler: **Break**, 3 attempts, 15 min.

**Module 8 – Data store › Add/replace a record** key `daily-{{formatDate(now; "YYYY-MM-DD")}}`,
scenario `daily_feed`, status `{{7.data.status}}`, detail `{{7.data.message}}`, executionId,
finishedAt `{{now}}`.

Scenario settings: incomplete executions **Yes**, consecutive errors **3**. Turn **ON**.

---

## Part F – Power Apps changes

### F1. App.Formulas additions

```powerfx
gblInbox = "TO FILL@hook.us2.make.com";   // same as env var RB Recipe Inbox
gblIsEditor = gblRole = "Editor";
```

### F2. scrBrowse – "Today's picks"

Add a horizontal gallery `galPicks` above `galRecipes`:

```powerfx
// galPicks.Items
SortByColumns(
    AddColumns(Filter('Featured Recipes', 'Is Active'),
               Ord, Switch(Slot, "breakfast", 1, "dinner", 2, 3)),
    "Ord")
```

Card: image `ThisItem.'Thumbnail Url'`, `ThisItem.Title`, a slot label
`Proper(ThisItem.Slot) & " · " & ThisItem.Area`, a veg badge, and *Import*:

```powerfx
// btnPickImport.DisplayMode
If(IsBlank(LookUp(Recipes, 'Recipe Code' = "mealdb-" & ThisItem.'Meal Id' &&
                           'Submitted By' = User().Email)),
   DisplayMode.Edit, DisplayMode.Disabled)

// btnPickImport.OnSelect  (V6 C7 import rules, data from the Featured Recipe row)
With({ing: Filter(ForAll(Split(ThisItem.'Ingredient Lines', Char(10)) As x, {L: Trim(x.Value)}), Len(L) > 1),
      st:  Filter(ForAll(Split(Substitute(ThisItem.Instructions, Char(13), ""), Char(10)) As s,
                         {L: Trim(s.Value)}), Len(L) > 1)},
  Set(varSaved, Patch(Recipes, Defaults(Recipes), {
     Title: ThisItem.Title, Category: ThisItem.'App Category',
     Blurb: Left(ThisItem.Area & " " & ThisItem.'Meal Category' & " recipe from TheMealDB", 140),
     'Image Url': ThisItem.'Thumbnail Url', 'Image Alt': "Photo of " & ThisItem.Title,
     'Time Label': "Time varies", 'Is Veg': ThisItem.'Is Veg',
     'Base Servings': 2, 'Serving Options': "1,2,4", 'Serving Unit Label': "serving",
     Keywords: Lower(ThisItem.Title & " " & ThisItem.Area & " " & ThisItem.'Meal Category'),
     Source: "imported", Status: "draft", 'Submitted By': User().Email,
     'Recipe Code': "mealdb-" & ThisItem.'Meal Id', 'Source Url': ThisItem.'Source Url',
     'Intake Channel': "featured"}));
  ForAll(Sequence(CountRows(ing)) As n,
    With({L: Index(ing, n.Value).L},
      With({m: Match(L, "^(?<amt>\d+ \d+/\d+|\d+/\d+|\d+(?:\.\d+)?) ?(?<rest>.*)$")},
        Patch(Ingredients, Defaults(Ingredients), {Name: varSaved.'Recipe Code' & "-I" & Text(n.Value, "00"),
          Recipe: varSaved, 'Line No': n.Value,
          Amount: If(IsBlank(m), Blank(), ParseAmount(m.amt)),
          Text: If(IsBlank(m), L, m.rest)}))));
  ForAll(Sequence(CountRows(st)) As n,
    Patch(Steps, Defaults(Steps), {Name: varSaved.'Recipe Code' & "-S" & Text(n.Value, "00"),
      Recipe: varSaved, 'Step No': n.Value, Text: Left(Index(st, n.Value).L, 600)}));
  Patch(Recipes, varSaved, {'Search Text': Lower(varSaved.Keywords & " " & Concat(ing, L, " "))}));
Notify("Imported as your own draft recipe", NotificationType.Success)
```

Empty state label: `Visible = CountRows(galPicks.AllItems) = 0`,
`Text = "Today's picks arrive at 6 a.m."`.

### F3. scrEmailRecipe (new) – nav button "Email a recipe"

- `lblInbox.Text = gblInbox`; `btnCopy.OnSelect = Copy(gblInbox); Notify("Address copied", NotificationType.Success)`
- Template label (one block of text):

```
Subject: <recipe name>
Category: breakfast / dinner / dessert
Time: <minutes> mins   Serves: <number>   Vegetarian: yes/no
Ingredients:
- 2 cups rice
- 1 1/2 tbsp soy sauce
Steps:
1. ...
2. ...
```

- Privacy note label: *"Send from the address you sign in with. Only the text of your
  email is sent to Google Gemini to read the recipe – please leave out personal details.
  Your recipe arrives as a private draft; nothing is published until a reviewer approves it."*

### F4. scrMySubmissions additions

- Badge on `galMine`: `If(ThisItem.'Intake Channel' = "email", "From email", ThisItem.'Intake Channel' = "featured", "Today's pick", "")`
- Below the timeline: `lblImportNotes.Text = galMine.Selected.'Import Notes'`,
  `Visible = !IsBlank(Self.Text)`, header "AI notes from your email (please check)".

### F5. scrIntegrations (new, Editor only) – nav button `Visible = gblIsEditor`

```powerfx
// scrIntegrations.OnVisible
If(!gblIsEditor, Navigate(scrBrowse));
ClearCollect(colLog, Filter('Integration Logs', 'Logged On' >= DateAdd(Now(), -7, TimeUnit.Days)));
Set(varFeedLast, First(Sort(Filter(colLog, Integration = "daily_feed" &&
                                    (Status = "success" || Status = "partial")),
                            'Logged On', SortOrder.Descending)));
Set(varMailLast, First(Sort(Filter(colLog, Integration = "email_intake" &&
                                    (Status = "success" || Status = "duplicate")),
                            'Logged On', SortOrder.Descending)))
```

Daily-feed tile:

```powerfx
// rectFeed.Fill
If(IsBlank(varFeedLast) || DateDiff(varFeedLast.'Logged On', Now(), TimeUnit.Hours) > 26,
     RGBA(220, 38, 38, 1),               // red: stale or never ran
   varFeedLast.Status = "partial", RGBA(217, 119, 6, 1),   // amber
   RGBA(22, 163, 74, 1))                 // green
// lblFeed.Text
"Daily feed · last success " & If(IsBlank(varFeedLast), "never",
    Text(varFeedLast.'Logged On', "ddd hh:mm")) & " · " &
CountRows(Filter(colLog, Integration = "daily_feed" && Status = "failed")) & " failed in 7 days"
```

Email-intake tile: red if any `failed` row for `email_intake` in the last 24 h, else green;
text = counts of `success`, `duplicate`, `rejected`, `failed` in 7 days and
`"avg " & Text(Average(Filter(colLog, Integration = "email_intake" && Status = "success"), 'Duration Ms'), "0") & " ms"`.

Failures gallery:

```powerfx
// galFailures.Items
Sort(Filter(colLog, Status in ["failed", "rejected", "partial", "unauthorized", "stale"]),
     'Logged On', SortOrder.Descending)
// row text
Text(ThisItem.'Logged On', "dd mmm hh:mm") & " · " & ThisItem.Integration & " · " &
ThisItem.Action & " · " & ThisItem.Status & " (" & ThisItem.'Http Status' & ")"
// second line
ThisItem.Detail & "  ·  Make run " & ThisItem.'Make Execution Id'
```

---

## Part G – Flow 2 addition: staleness check (monitor outside Make)

Open V6 Flow 2 `RB – Review reminders` (runs daily 09:00, three hours after Scenario B) and add,
in parallel with the reminder branch:

1. **List rows** *Integration Logs* – Filter rows
   `cr_integration eq 'daily_feed' and (cr_status eq 'success' or cr_status eq 'partial') and cr_loggedon gt @{addHours(utcNow(), -26)}`,
   Row count `1`.
2. **Condition** `length(outputs('List_feed_logs')?['body/value'])` *is equal to* `0`:
   - Yes → **Send an email (V2)** to `RB Admin Email`: subject "Recipe Box: daily feed is stale",
     body "No successful daily_feed run in 26 hours. Check Make → RB-B → History and Incomplete
     executions, and the Make credit balance." → **Add a new row** *Integration Logs*:
     Request Id `monitor-@{formatDateTime(utcNow(),'yyyy-MM-dd')}`, Integration `monitor`,
     Action `stalenessCheck`, Status `stale`, Logged On `utcNow()`.

Testing (M-1): temporarily change `-26` to `addMinutes(utcNow(), -1)`, run once, change back,
and note it in the test log.

---

## Part H – Export (deliverable)

1. Power Platform: Solutions → Recipe Box V7 → **Export** → Unmanaged →
   `RecipeBoxV7_1_1_0_0.zip` → `app-export/`. Also app editor → File → Save as → This computer →
   `Recipe Box V7.msapp` → `app-export/`.
2. Make: each scenario → ⋯ → **Export blueprint** → save as
   `make/blueprints/RB-A_Email_to_Recipe.blueprint.json` and `RB-B_Daily_Inspiration.blueprint.json`.
   Blueprints do not include connections or keys, so they are safe to submit.
3. Fill `links.txt`, export the documentation doc to PDF as `ITC6250_Version7_KhushiPatel.pdf`
   (root of this folder), work through `SUBMISSION_STATUS.md`, then delete it and zip the folder.
