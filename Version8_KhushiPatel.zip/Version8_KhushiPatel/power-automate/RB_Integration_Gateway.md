# Flow 4 – `RB – Integration Gateway` (Power Automate, instant HTTP)

Create inside solution **Recipe Box V7** → New → Automation → Cloud flow → Instant →
*When an HTTP request is received*. All Dataverse actions use the V6 connection. Replace
`cr_` with your prefix. Action names below are the names to give each action (expressions
refer to them).

## 1. Trigger and start

1. **When an HTTP request is received** – Method POST; *Who can trigger* = Anyone; Request
   Body JSON Schema = `gateway_request.schema.json`. *Settings → Schema validation* **On**
   (a body that fails the schema gets HTTP 400 automatically and Make's Break handles it).
2. **Initialize variable** `varStart` (String) = `utcNow()`
3. **Initialize variable** `varStatus` (String) = `failed`, `varCode` (Integer) = `500`,
   `varMessage` (String) = `''`, `varRecords` (Integer) = `0`, `varRecipeCode` (String) = `''`
4. **Compose `Payload`** = `triggerBody()?['payload']`

## 2. Key check

5. **Condition `Key valid`**:
   `equals(triggerOutputs()?['headers']?['x-rb-key'], parameters('RB Integration Key (cr_RBIntegrationKey)'))`
   - **No** → *Add a new row* Integration Logs (Status `unauthorized`, Http Status 401, Detail
     "Missing or wrong x-rb-key", Request Id, Make Execution Id, Logged On `utcNow()`) →
     **Response** 401 `{"status":"unauthorized","code":401}` → **Terminate** (Succeeded).

## 3. Scope `Try`

6. **Switch** on `triggerBody()?['action']`

### Case `createDraftFromEmail`

a. **List rows** *App Users* – Filter `cr_email eq '@{toLower(outputs('Payload')?['senderEmail'])}'`, Row count 1.
b. **Condition `Registered sender`** – `length(outputs('List_app_users')?['body/value'])` greater than 0.
   - No → Set `varStatus` = `rejected`, `varCode` = 403, `varMessage` = `Sender is not a registered Recipe Box user`.
     *(No email reply – avoids sending mail to strangers.)*
   - Yes → continue:
c. **List rows** *Recipes* – Filter `cr_intakeref eq '@{triggerBody()?['requestId']}'`, Row count 1.
d. **Condition `Already created`** – length > 0 → Set `varStatus` = `duplicate`, `varCode` = 200,
   `varRecipeCode` = `first(outputs('List_existing')?['body/value'])?['cr_recipecode']`.
e. Else **Compose `Recipe`** = `outputs('Payload')?['recipe']`, then **Filter array `Clean ingredients`**
   From `take(coalesce(outputs('Recipe')?['ingredients'], createArray()), 40)`,
   condition `length(trim(coalesce(item()?['text'], '')))` greater than 0.
   **Filter array `Clean steps`** From `take(coalesce(outputs('Recipe')?['steps'], createArray()), 30)`,
   condition `length(trim(coalesce(item(), '')))` greater than 0.
f. **Condition `Valid`** (server-side re-check – never trust the caller):
   ```
   and(
     greater(length(trim(coalesce(outputs('Recipe')?['title'], ''))), 0),
     contains(createArray('breakfast','dinner','dessert'), outputs('Recipe')?['category']),
     greater(length(body('Clean_ingredients')), 0),
     greater(length(body('Clean_steps')), 0),
     or(equals(outputs('Recipe')?['minutes'], null),
        and(greaterOrEquals(int(outputs('Recipe')?['minutes']), 1), lessOrEquals(int(outputs('Recipe')?['minutes']), 1440))),
     and(greaterOrEquals(int(coalesce(outputs('Recipe')?['servings'], 2)), 1), lessOrEquals(int(coalesce(outputs('Recipe')?['servings'], 2)), 50))
   )
   ```
   - No → `varStatus` = `rejected`, `varCode` = 422, `varMessage` = `Recipe failed validation`.
   - Yes →
g. **List rows** *Users* (systemuser) – Filter `internalemailaddress eq '@{toLower(outputs('Payload')?['senderEmail'])}'`, Row count 1.
h. **Compose `Code`** = `concat('e', formatDateTime(utcNow(), 'yyyyMMddHHmmss'))`
i. **Add a new row** *Recipes*:

   | Column | Value |
   |---|---|
   | Title | `substring(trim(outputs('Recipe')?['title']), 0, min(120, length(trim(outputs('Recipe')?['title']))))` |
   | Recipe Code | `outputs('Code')` |
   | Category | `outputs('Recipe')?['category']` |
   | Blurb | `coalesce(outputs('Recipe')?['blurb'], 'Sent by email.')` |
   | Time Minutes | `outputs('Recipe')?['minutes']` |
   | Time Label | `if(equals(outputs('Recipe')?['minutes'], null), 'Time varies', concat(string(outputs('Recipe')?['minutes']), ' mins'))` |
   | Is Veg | `coalesce(outputs('Recipe')?['isVeg'], false)` |
   | Base Servings | `coalesce(outputs('Recipe')?['servings'], 2)` |
   | Serving Options | `'1,2,4'` |
   | Serving Unit Label | `serving` |
   | Image Url / Image Alt | `concat('images/placeholder-', outputs('Recipe')?['category'], '.svg')` / `concat('Placeholder illustration for ', outputs('Recipe')?['title'])` |
   | Source | `custom` · Status `draft` · Intake Channel `email` |
   | Intake Ref | `triggerBody()?['requestId']` |
   | Submitted By | `toLower(outputs('Payload')?['senderEmail'])` |
   | Import Notes | `concat('AI confidence: ', string(coalesce(outputs('Payload')?['ai']?['confidence'], 0)), decodeUriComponent('%0A'), join(coalesce(outputs('Payload')?['ai']?['warnings'], createArray()), decodeUriComponent('%0A')))` |
   | Keywords | `toLower(concat(outputs('Recipe')?['title'], ' ', outputs('Recipe')?['category'], ' email mine custom'))` |
   | Search Text | `toLower(concat(outputs('Recipe')?['title'], ' ', join(body('Select_ingredient_text'), ' ')))` (add **Select `Select_ingredient_text`** from Clean ingredients, map `item()?['text']`, before this action) |
   | **Owner** | `if(greater(length(outputs('List_users')?['body/value']), 0), concat('/systemusers(', first(outputs('List_users')?['body/value'])?['systemuserid'], ')'), null)` |

j. **Apply to each** `range(0, length(body('Clean_ingredients')))` → **Add a new row** *Ingredients*:
   Name `concat(outputs('Code'), '-I', formatNumber(add(item(), 1), '00'))`, Recipe (lookup)
   `concat('cr_recipes(', outputs('Add_recipe')?['body/cr_recipeid'], ')')`, Line No `add(item(), 1)`,
   Amount `if(or(equals(body('Clean_ingredients')[item()]?['amount'], null), less(float(body('Clean_ingredients')[item()]?['amount']), 0)), null, float(body('Clean_ingredients')[item()]?['amount']))`,
   Text `substring(trim(body('Clean_ingredients')[item()]?['text']), 0, min(300, length(trim(body('Clean_ingredients')[item()]?['text']))))`.
k. **Apply to each** `range(0, length(body('Clean_steps')))` → **Add a new row** *Steps*: Name
   `concat(outputs('Code'), '-S', formatNumber(add(item(), 1), '00'))`, Recipe (lookup), Step No
   `add(item(), 1)`, Text `substring(trim(body('Clean_steps')[item()]), 0, min(600, length(trim(body('Clean_steps')[item()]))))`.
l. **Add a new row** *Workflow Audits*: Action `Created from email`, Actor `Make RB-A`, Actor Type `System`,
   From Status `''`, To Status `draft`, Notes `concat('Make run ', triggerBody()?['makeExecutionId'])`, Logged On `utcNow()`.
m. **Send an email (V2)** to the sender: subject `Your recipe "@{outputs('Recipe')?['title']}" is saved as a draft`;
   body: deep link `@{parameters('RB App URL (cr_RBAppURL)')}&recipeId=@{outputs('Code')}`, the AI warnings,
   "Please check the quantities before you submit it for publishing."
n. Set `varStatus` = `created`, `varCode` = 201, `varRecipeCode` = `outputs('Code')`,
   `varRecords` = `add(add(1, length(body('Clean_ingredients'))), length(body('Clean_steps')))`.

### Case `reportEmailFailure`

a. List rows *App Users* for the sender (as above).
b. If registered → **Send an email (V2)**: subject "We couldn't read your recipe", body = reason in plain words
   (`not_a_recipe` → "We didn't find ingredients and steps", `invalid` → "Some parts were missing",
   `ai_failed` → "Our recipe reader is unavailable right now") + the template from scrEmailRecipe.
c. Set `varStatus` = `logged`, `varCode` = 200, `varMessage` = `triggerBody()?['payload']?['reason']`.

### Case `upsertFeatured`

a. **Apply to each** `outputs('Payload')?['meals']` (Concurrency 1):
   - **List rows** *Featured Recipes* – Filter
     `cr_featuredate eq '@{outputs('Payload')?['featureDate']}' and cr_slot eq '@{items('Apply_to_each_meal')?['slot']}'`, Row count 1.
   - **Select `Lines`** from `split(coalesce(items('Apply_to_each_meal')?['ingredientLines'], ''), decodeUriComponent('%0A'))`
     → **Filter array** `greater(length(trim(item())), 1)` → **Compose `CleanLines`** = `join(body('Filter_lines'), decodeUriComponent('%0A'))`.
   - **Condition** exists → **Update a row** (that row) else **Add a new row**, with: Title, Feature Date, Slot,
     Meal Id, App Category, Meal Category, Area, Is Veg, Thumbnail Url, Ingredient Lines = `outputs('CleanLines')`,
     Instructions, Source Url, **Is Active = Yes**.
   - **Increment** `varRecords`.
b. **List rows** *Featured Recipes* – Filter `cr_isactive eq true and cr_featuredate ne '@{outputs('Payload')?['featureDate']}'`
   → Apply to each → **Update a row** Is Active = No.
c. Set `varStatus` = `if(outputs('Payload')?['partial'], 'partial', 'upserted')`, `varCode` = 200.

## 4. Scope `Catch` – *Configure run after*: `Try` **has failed, has timed out**

- `varStatus` = `failed`, `varCode` = 500,
  `varMessage` = `string(first(result('Try'))?['error'])` (or the failed action's message)
- **Send an email (V2)** to `RB Admin Email`: "Integration Gateway error" + request ID + Make execution ID +
  link to this run `concat('https://make.powerautomate.com/environments/', workflow()?['tags']?['environmentName'], '/flows/', workflow()?['name'], '/runs/', workflow()?['run']?['name'])`.

## 5. Scope `Finally` – run after `Catch` **is successful, has failed, is skipped, has timed out**

- **Add a new row** *Integration Logs*:

  | Column | Value |
  |---|---|
  | Request Id | `triggerBody()?['requestId']` |
  | Integration | `triggerBody()?['integration']` |
  | Action | `triggerBody()?['action']` |
  | Status | `if(equals(variables('varStatus'), 'created'), 'success', if(equals(variables('varStatus'), 'upserted'), 'success', if(equals(variables('varStatus'), 'logged'), 'success', variables('varStatus'))))` |
  | Http Status | `variables('varCode')` |
  | Make Execution Id | `triggerBody()?['makeExecutionId']` |
  | Records Affected | `variables('varRecords')` |
  | Detail | `variables('varMessage')` |
  | Sender | `coalesce(triggerBody()?['payload']?['senderEmail'], '')` |
  | Duration Ms | `div(sub(ticks(utcNow()), ticks(variables('varStart'))), 10000)` |
  | Logged On | `utcNow()` |

- **Response** – Status code `if(equals(variables('varCode'), 500), 500, if(equals(variables('varCode'), 201), 201, 200))`,
  Headers `Content-Type: application/json`, Body:
  ```json
  {"status":"@{variables('varStatus')}","code":@{variables('varCode')},"recipeCode":"@{variables('varRecipeCode')}","message":"@{variables('varMessage')}"}
  ```

> Responses inside Try/Catch would fire before logging; keeping **one Response in Finally**
> guarantees every request is logged first and answered exactly once.

## Settings

- Trigger concurrency: **On, degree 1** for predictable duplicate checks (email volume is low).
- Run history 28 days (default) – the system-level log; Integration Log is the business-level one.
- Turn on **flow failure notifications** (owner email).
