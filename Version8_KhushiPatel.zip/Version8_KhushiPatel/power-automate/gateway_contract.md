# Integration Gateway – request/response contract

**Endpoint:** Power Automate *When an HTTP request is received* (POST URL with `sig=`).
**Auth:** header `x-rb-key` = environment variable `RB Integration Key`.
**Rule:** business outcomes are returned in the body with HTTP 200/201; only technical
failures use HTTP error codes. Make retries HTTP errors (Break) and never retries a body
`status`.

## Envelope (all actions)

| Field | Type | Notes |
|---|---|---|
| action | text | `createDraftFromEmail` · `reportEmailFailure` · `upsertFeatured` |
| requestId | text ≤ 120 | `mail-<md5>` or `daily-<YYYY-MM-DD>`; idempotency key |
| integration | text | `email_intake` · `daily_feed` |
| makeExecutionId | text | correlation ID, stored in every Integration Log row |
| sentAt | ISO date-time | |
| payload | object | per action, below |

## payload by action

**createDraftFromEmail** – `senderEmail`, `subject`, `recipe {title, category, minutes|null,
servings, isVeg, blurb, ingredients[{amount|null, text}], steps[]}`, `ai {confidence, warnings[]}`,
`detail` (warnings joined). Example: `test-data/gateway/A1_createDraftFromEmail.json`.

**reportEmailFailure** – `senderEmail`, `subject`, `reason` (`not_a_recipe` · `invalid` ·
`ai_failed`), `detail`. Example: `A5_reportEmailFailure.json`.

**upsertFeatured** – `featureDate` (YYYY-MM-DD), `partial` (bool), `meals[]` of
`{slot, mealId, title, appCategory, mealCategory, area, isVeg, thumb, instructions,
ingredientLines, sourceUrl}`. Example: `B1_upsertFeatured.json`.

## Responses

| HTTP | body.status | When | Make does |
|---|---|---|---|
| 201 | `created` | Draft recipe created | ledger `created` |
| 200 | `duplicate` | Intake Ref already exists | ledger `duplicate` |
| 200 | `rejected` (code 403) | Sender not in App Users | ledger `rejected_by_app`, no retry |
| 200 | `rejected` (code 422) | Fails server-side validation | ledger `rejected_by_app`, no retry |
| 200 | `logged` | reportEmailFailure handled | ledger `needs_template` |
| 200 | `upserted` / `partial` | Featured rows written | ledger `success` / `partial` |
| 400 | `bad_request` | Body fails the trigger schema | Break → incomplete → alert |
| 401 | `unauthorized` | Missing/wrong `x-rb-key` | Break → incomplete → alert; resume after fixing key |
| 500 | `error` | Unexpected failure (Catch scope) | Break → retry 3× |

Body shape: `{"status": "...", "code": 201, "recipeCode": "e20261107...", "message": "...", "logId": "..."}`.
